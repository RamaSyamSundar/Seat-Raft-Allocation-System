package kv

import (
	"fmt"
	"testing"
)

func TestPutAndGet(t *testing.T) {
	store := NewStore()

	store.Put("seat/ROOM101/A01", "FREE")

	value, exists := store.Get("seat/ROOM101/A01")

	if !exists {
		t.Fatal("expected seat to exist")
	}

	if value != "FREE" {
		t.Fatalf("expected FREE, got %s", value)
	}
}

func TestDelete(t *testing.T) {
	store := NewStore()

	store.Put("seat/ROOM101/A01", "FREE")
	store.Delete("seat/ROOM101/A01")

	_, exists := store.Get("seat/ROOM101/A01")

	if exists {
		t.Fatal("expected seat to be deleted")
	}
}

func TestMissingKey(t *testing.T) {
	store := NewStore()

	_, exists := store.Get("seat/ROOM101/A99")

	if exists {
		t.Fatal("expected missing key")
	}
}
func TestConcurrentAllocation(t *testing.T) {
	store := NewStore()

	seat := "seat/ROOM101/A01"

	store.Put(seat, "FREE")

	const students = 100

	results := make(chan bool, students)

	for i := 0; i < students; i++ {
		go func(studentNumber int) {
			studentID := fmt.Sprintf("STU%03d", studentNumber)

			success := store.Allocate(seat, studentID)

			results <- success
		}(i)
	}

	successCount := 0

	for i := 0; i < students; i++ {
		if <-results {
			successCount++
		}
	}

	if successCount != 1 {
		t.Fatalf(
			"expected exactly 1 successful allocation, got %d",
			successCount,
		)
	}

	value, exists := store.Get(seat)

	if !exists {
		t.Fatal("seat should exist")
	}

	if len(value) < len("ALLOCATED:") {
		t.Fatalf("unexpected seat value: %s", value)
	}
}