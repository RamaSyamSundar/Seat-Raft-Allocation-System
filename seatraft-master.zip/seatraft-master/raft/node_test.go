package raft

import "seatraft/lsm"
import "testing"

func TestRequestVoteGranted(t *testing.T) {
	node := NewNode("node2")

	response := node.RequestVote(RequestVoteRequest{
		Term:        1,
		CandidateID: "node1",
	})

	if !response.VoteGranted {
		t.Fatal("expected vote to be granted")
	}

	if response.Term != 1 {
		t.Fatalf("expected term 1, got %d", response.Term)
	}
}

func TestRequestVoteOnlyOncePerTerm(t *testing.T) {
	node := NewNode("node2")

	firstResponse := node.RequestVote(RequestVoteRequest{
		Term:        1,
		CandidateID: "node1",
	})

	if !firstResponse.VoteGranted {
		t.Fatal("expected first vote to be granted")
	}

	secondResponse := node.RequestVote(RequestVoteRequest{
		Term:        1,
		CandidateID: "node3",
	})

	if secondResponse.VoteGranted {
		t.Fatal("expected second vote to be rejected")
	}
}

func TestRequestVoteSameCandidate(t *testing.T) {
	node := NewNode("node2")

	firstResponse := node.RequestVote(RequestVoteRequest{
		Term:        1,
		CandidateID: "node1",
	})

	if !firstResponse.VoteGranted {
		t.Fatal("expected first vote to be granted")
	}

	secondResponse := node.RequestVote(RequestVoteRequest{
		Term:        1,
		CandidateID: "node1",
	})

	if !secondResponse.VoteGranted {
		t.Fatal("expected same candidate vote to be granted")
	}
}

func TestRequestVoteRejectsOlderTerm(t *testing.T) {
	node := NewNode("node2")

	node.RequestVote(RequestVoteRequest{
		Term:        2,
		CandidateID: "node1",
	})

	response := node.RequestVote(RequestVoteRequest{
		Term:        1,
		CandidateID: "node3",
	})

	if response.VoteGranted {
		t.Fatal("expected older term vote to be rejected")
	}

	if response.Term != 2 {
		t.Fatalf("expected current term 2, got %d", response.Term)
	}
}

func TestRequestVoteUpdatesNewerTerm(t *testing.T) {
	node := NewNode("node2")

	response := node.RequestVote(RequestVoteRequest{
		Term:        5,
		CandidateID: "node1",
	})

	if !response.VoteGranted {
		t.Fatal("expected vote to be granted")
	}

	if response.Term != 5 {
		t.Fatalf("expected term 5, got %d", response.Term)
	}

	if node.CurrentTerm != 5 {
		t.Fatalf("expected node term 5, got %d", node.CurrentTerm)
	}

	if node.State != Follower {
		t.Fatal("expected node to remain follower")
	}
}
func TestStartElection(t *testing.T) {
	node := NewNode("node1")

	node.StartElection()

	if node.State != Candidate {
		t.Fatal("expected node to become candidate")
	}

	if node.CurrentTerm != 1 {
		t.Fatalf("expected term 1, got %d", node.CurrentTerm)
	}

	if node.VotedFor != "node1" {
		t.Fatalf("expected node to vote for itself, got %s", node.VotedFor)
	}
}
func TestBecomeLeader(t *testing.T) {
	node := NewNode("node1")

	node.StartElection()

	node.BecomeLeader()

	if node.State != Leader {
		t.Fatal("expected node to become leader")
	}
}
func TestAppendEntry(t *testing.T) {
	node := NewNode("node1")

	node.StartElection()
	node.BecomeLeader()

	node.AppendEntry(
		"ALLOCATE_SEAT",
		"seat/ROOM101/A01",
		"STU123",
	)

	if len(node.Log) != 1 {
		t.Fatalf("expected 1 log entry, got %d", len(node.Log))
	}

	entry := node.Log[0]

	if entry.Term != 1 {
		t.Fatalf("expected term 1, got %d", entry.Term)
	}

	if entry.Command != "ALLOCATE_SEAT" {
		t.Fatalf("expected ALLOCATE_SEAT, got %s", entry.Command)
	}

	if entry.Key != "seat/ROOM101/A01" {
		t.Fatalf("unexpected key: %s", entry.Key)
	}

	if entry.Value != "STU123" {
		t.Fatalf("unexpected value: %s", entry.Value)
	}
}
func TestAppendEntries(t *testing.T) {
	node := NewNode("node2")

	entry := LogEntry{
		Term:    1,
		Command: "ALLOCATE_SEAT",
		Key:     "seat/ROOM101/A01",
		Value:   "STU123",
	}

	response := node.AppendEntries(AppendEntriesRequest{
		Term:         1,
		LeaderID:     "node1",
		PrevLogIndex: 0,
		PrevLogTerm:  0,
		Entries:      []LogEntry{entry},
		LeaderCommit: 0,
	})

	if !response.Success {
		t.Fatal("expected AppendEntries to succeed")
	}

	if response.Term != 1 {
		t.Fatalf("expected term 1, got %d", response.Term)
	}

	if node.State != Follower {
		t.Fatal("expected node to remain follower")
	}

	if len(node.Log) != 1 {
		t.Fatalf("expected 1 log entry, got %d", len(node.Log))
	}

	if node.Log[0].Command != "ALLOCATE_SEAT" {
		t.Fatalf(
			"expected ALLOCATE_SEAT, got %s",
			node.Log[0].Command,
		)
	}
}
func TestAppendEntriesRejectsOlderTerm(t *testing.T) {
	node := NewNode("node2")

	node.CurrentTerm = 2

	response := node.AppendEntries(AppendEntriesRequest{
		Term:     1,
		LeaderID: "node1",
	})

	if response.Success {
		t.Fatal("expected older-term AppendEntries to be rejected")
	}

	if response.Term != 2 {
		t.Fatalf("expected term 2, got %d", response.Term)
	}
}
func TestNewCluster(t *testing.T) {
	cluster := NewCluster([]string{
		"node1",
		"node2",
		"node3",
	})

	if len(cluster.Nodes) != 3 {
		t.Fatalf(
			"expected 3 nodes, got %d",
			len(cluster.Nodes),
		)
	}

	if cluster.Nodes["node1"] == nil {
		t.Fatal("node1 was not created")
	}

	if cluster.Nodes["node2"] == nil {
		t.Fatal("node2 was not created")
	}

	if cluster.Nodes["node3"] == nil {
		t.Fatal("node3 was not created")
	}

	if cluster.Nodes["node1"].State != Follower {
		t.Fatal("node1 should start as follower")
	}

	if cluster.Nodes["node2"].State != Follower {
		t.Fatal("node2 should start as follower")
	}

	if cluster.Nodes["node3"].State != Follower {
		t.Fatal("node3 should start as follower")
	}
}
func TestClusterReplicate(t *testing.T) {
	cluster := NewCluster([]string{
		"node1",
		"node2",
		"node3",
	})

	leader := cluster.Nodes["node1"]

	leader.StartElection()
	leader.BecomeLeader()

	entry := LogEntry{
		Term:    leader.CurrentTerm,
		Command: "ALLOCATE_SEAT",
		Key:     "seat/ROOM101/A01",
		Value:   "STU123",
	}

	success := cluster.Replicate("node1", entry)

	if !success {
		t.Fatal("expected replication to reach a majority")
	}

	if len(cluster.Nodes["node1"].Log) != 1 {
		t.Fatalf(
			"expected leader log length 1, got %d",
			len(cluster.Nodes["node1"].Log),
		)
	}

	if len(cluster.Nodes["node2"].Log) != 1 {
		t.Fatalf(
			"expected node2 log length 1, got %d",
			len(cluster.Nodes["node2"].Log),
		)
	}

	if len(cluster.Nodes["node3"].Log) != 1 {
		t.Fatalf(
			"expected node3 log length 1, got %d",
			len(cluster.Nodes["node3"].Log),
		)
	}

	if cluster.Nodes["node2"].Log[0].Command != "ALLOCATE_SEAT" {
		t.Fatal("node2 received incorrect log entry")
	}

	if cluster.Nodes["node3"].Log[0].Command != "ALLOCATE_SEAT" {
		t.Fatal("node3 received incorrect log entry")
	}
}
func TestClusterReplicateCommitsEntry(t *testing.T) {
	cluster := NewCluster([]string{
		"node1",
		"node2",
		"node3",
	})

	leader := cluster.Nodes["node1"]

	leader.StartElection()
	leader.BecomeLeader()

	entry := LogEntry{
		Term:    leader.CurrentTerm,
		Command: "ALLOCATE_SEAT",
		Key:     "seat/ROOM101/A01",
		Value:   "STU123",
	}

	success := cluster.Replicate("node1", entry)

	if !success {
		t.Fatal("expected replication to succeed")
	}

	if leader.CommitIndex != 1 {
		t.Fatalf(
			"expected CommitIndex 1, got %d",
			leader.CommitIndex,
		)
	}
}
func TestApplyCommittedAllocation(t *testing.T) {
	dir := t.TempDir()

	db, err := lsm.OpenDB(dir)
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()

	sm := NewStateMachine(db)

	cluster := NewCluster([]string{
		"node1",
		"node2",
		"node3",
	})

	leader := cluster.Nodes["node1"]

	leader.SetStateMachine(sm)

	leader.StartElection()
	leader.BecomeLeader()

	// Create the seat in the LSM-backed state machine.
	err = db.Put(
		"seat/ROOM101/A01",
		"FREE",
	)
	if err != nil {
		t.Fatal(err)
	}

	entry := LogEntry{
		Term:    leader.CurrentTerm,
		Command: "ALLOCATE_SEAT",
		Key:     "seat/ROOM101/A01",
		Value:   "STU123",
	}

	success := cluster.Replicate("node1", entry)

	if !success {
		t.Fatal("expected replication to succeed")
	}

	if leader.CommitIndex != 1 {
		t.Fatalf(
			"expected CommitIndex 1, got %d",
			leader.CommitIndex,
		)
	}

	value, exists := db.Get(
		"seat/ROOM101/A01",
	)

	if !exists {
		t.Fatal("expected seat to exist")
	}

	if value != "ALLOCATED:STU123" {
		t.Fatalf(
			"expected ALLOCATED:STU123, got %s",
			value,
		)
	}

	if leader.LastApplied != 1 {
		t.Fatalf(
			"expected LastApplied 1, got %d",
			leader.LastApplied,
		)
	}
}
func TestClusterReplicateAppliesToAllNodes(t *testing.T) {
	cluster := NewCluster([]string{
		"node1",
		"node2",
		"node3",
	})

	dbs := make(map[string]*lsm.DB)

	for id, node := range cluster.Nodes {
		dir := t.TempDir()

		db, err := lsm.OpenDB(dir)
		if err != nil {
			t.Fatal(err)
		}

		dbs[id] = db
		node.SetStateMachine(NewStateMachine(db))

		err = db.Put(
			"seat/ROOM101/A01",
			"FREE",
		)
		if err != nil {
			t.Fatal(err)
		}
	}

	defer func() {
		for _, db := range dbs {
			_ = db.Close()
		}
	}()

	leader := cluster.Nodes["node1"]

	leader.StartElection()
	leader.BecomeLeader()

	entry := LogEntry{
		Term:    leader.CurrentTerm,
		Command: "ALLOCATE_SEAT",
		Key:     "seat/ROOM101/A01",
		Value:   "STU123",
	}

	success := cluster.Replicate("node1", entry)

	if !success {
		t.Fatal("expected replication to succeed")
	}

	for id, node := range cluster.Nodes {
		value, exists := dbs[id].Get(
			"seat/ROOM101/A01",
		)

		if !exists {
			t.Fatalf("%s: expected seat to exist", id)
		}

		if value != "ALLOCATED:STU123" {
			t.Fatalf(
				"%s: expected ALLOCATED:STU123, got %s",
				id,
				value,
			)
		}

		if node.CommitIndex != 1 {
			t.Fatalf(
				"%s: expected CommitIndex 1, got %d",
				id,
				node.CommitIndex,
			)
		}

		if node.LastApplied != 1 {
			t.Fatalf(
				"%s: expected LastApplied 1, got %d",
				id,
				node.LastApplied,
			)
		}
	}
}
func TestElectLeader(t *testing.T) {
	cluster := NewCluster([]string{
		"node1",
		"node2",
		"node3",
	})

	success := cluster.ElectLeader("node1")

	if !success {
		t.Fatal("expected node1 to become leader")
	}

	if cluster.Nodes["node1"].State != Leader {
		t.Fatal("expected node1 to be leader")
	}

	if cluster.Nodes["node1"].CurrentTerm != 1 {
		t.Fatalf(
			"expected term 1, got %d",
			cluster.Nodes["node1"].CurrentTerm,
		)
	}

	if cluster.Nodes["node2"].VotedFor != "node1" {
		t.Fatalf(
			"expected node2 to vote for node1, got %s",
			cluster.Nodes["node2"].VotedFor,
		)
	}

	if cluster.Nodes["node3"].VotedFor != "node1" {
		t.Fatalf(
			"expected node3 to vote for node1, got %s",
			cluster.Nodes["node3"].VotedFor,
		)
	}
}
func TestOnlyOneVotePerTerm(t *testing.T) {
	node := NewNode("node3")

	firstResponse := node.RequestVote(RequestVoteRequest{
		Term:        1,
		CandidateID: "node1",
	})

	if !firstResponse.VoteGranted {
		t.Fatal("expected node3 to vote for node1")
	}

	secondResponse := node.RequestVote(RequestVoteRequest{
		Term:        1,
		CandidateID: "node2",
	})

	if secondResponse.VoteGranted {
		t.Fatal("expected node3 to reject node2 in the same term")
	}

	if node.VotedFor != "node1" {
		t.Fatalf(
			"expected node3 to remain voted for node1, got %s",
			node.VotedFor,
		)
	}
}
func TestHeartbeat(t *testing.T) {
	node := NewNode("node1")

	node.StartElection()
	node.BecomeLeader()

	heartbeat := node.Heartbeat()

	if heartbeat.Term != node.CurrentTerm {
		t.Fatalf(
			"expected heartbeat term %d, got %d",
			node.CurrentTerm,
			heartbeat.Term,
		)
	}

	if heartbeat.LeaderID != "node1" {
		t.Fatalf(
			"expected leader ID node1, got %s",
			heartbeat.LeaderID,
		)
	}

	if len(heartbeat.Entries) != 0 {
		t.Fatalf("expected heartbeat to have no entries")
	}

	if heartbeat.LeaderCommit != node.CommitIndex {
		t.Fatalf(
			"expected LeaderCommit %d, got %d",
			node.CommitIndex,
			heartbeat.LeaderCommit,
		)
	}
}
func TestHeartbeatReceivedByFollower(t *testing.T) {
	leader := NewNode("node1")
	follower := NewNode("node2")

	leader.StartElection()
	leader.BecomeLeader()

	heartbeat := leader.Heartbeat()

	response := follower.AppendEntries(heartbeat)

	if !response.Success {
		t.Fatal("expected heartbeat to be accepted")
	}

	if follower.State != Follower {
		t.Fatal("expected follower to remain follower")
	}

	if follower.CurrentTerm != leader.CurrentTerm {
		t.Fatalf(
			"expected follower term %d, got %d",
			leader.CurrentTerm,
			follower.CurrentTerm,
		)
	}

	if len(follower.Log) != 0 {
		t.Fatalf(
			"expected follower log to remain empty, got %d entries",
			len(follower.Log),
		)
	}
}
func TestHeartbeatPropagatesCommitIndex(t *testing.T) {
	dir := t.TempDir()

	db, err := lsm.OpenDB(dir)
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()

	sm := NewStateMachine(db)

	leader := NewNode("node1")
	follower := NewNode("node2")

	follower.SetStateMachine(sm)

	leader.StartElection()
	leader.BecomeLeader()

	// Create the seat in the LSM.
	err = db.Put(
		"seat/ROOM101/A01",
		"FREE",
	)
	if err != nil {
		t.Fatal(err)
	}

	// Add the committed entry to both logs.
	entry := LogEntry{
		Term:    leader.CurrentTerm,
		Command: "ALLOCATE_SEAT",
		Key:     "seat/ROOM101/A01",
		Value:   "STU123",
	}

	leader.Log = append(leader.Log, entry)
	follower.Log = append(follower.Log, entry)

	leader.CommitIndex = 1

	heartbeat := leader.Heartbeat()

	response := follower.AppendEntries(heartbeat)

	if !response.Success {
		t.Fatal("expected heartbeat to succeed")
	}

	if follower.CommitIndex != 1 {
		t.Fatalf(
			"expected follower CommitIndex 1, got %d",
			follower.CommitIndex,
		)
	}

	follower.ApplyCommitted()

	value, exists := db.Get(
		"seat/ROOM101/A01",
	)

	if !exists {
		t.Fatal("expected seat to exist")
	}

	if value != "ALLOCATED:STU123" {
		t.Fatalf(
			"expected ALLOCATED:STU123, got %s",
			value,
		)
	}

	if follower.LastApplied != 1 {
		t.Fatalf(
			"expected LastApplied 1, got %d",
			follower.LastApplied,
		)
	}
}
func TestAppendEntriesRejectsLogMismatch(t *testing.T) {
	follower := NewNode("node2")

	follower.CurrentTerm = 2

	follower.Log = append(follower.Log, LogEntry{
		Term:    1,
		Command: "PUT",
		Key:     "seat/ROOM101/A01",
		Value:   "FREE",
	})

	response := follower.AppendEntries(
		AppendEntriesRequest{
			Term:         2,
			LeaderID:     "node1",
			PrevLogIndex: 0,
			PrevLogTerm:  99,
			Entries: []LogEntry{
				{
					Term:    2,
					Command: "PUT",
					Key:     "seat/ROOM101/A01",
					Value:   "ALLOCATED:STU123",
				},
			},
			LeaderCommit: 0,
		},
	)

	if response.Success {
		t.Fatal("expected AppendEntries to be rejected because of log mismatch")
	}

	if len(follower.Log) != 1 {
		t.Fatalf(
			"expected follower log length 1, got %d",
			len(follower.Log),
		)
	}
}
func TestAppendEntriesDoesNotOverwriteOnLogMismatch(t *testing.T) {
	follower := NewNode("node2")

	follower.CurrentTerm = 2

	follower.Log = append(follower.Log, LogEntry{
		Term:    1,
		Command: "PUT",
		Key:     "seat/ROOM101/A01",
		Value:   "FREE",
	})

	response := follower.AppendEntries(
		AppendEntriesRequest{
			Term:         2,
			LeaderID:     "node1",
			PrevLogIndex: 0,
			PrevLogTerm:  99,
			Entries: []LogEntry{
				{
					Term:    2,
					Command: "PUT",
					Key:     "seat/ROOM101/A01",
					Value:   "ALLOCATED:STU999",
				},
			},
			LeaderCommit: 0,
		},
	)

	if response.Success {
		t.Fatal("expected AppendEntries to be rejected")
	}

	if len(follower.Log) != 1 {
		t.Fatalf(
			"expected log length 1, got %d",
			len(follower.Log),
		)
	}

	entry := follower.Log[0]

	if entry.Term != 1 {
		t.Fatalf(
			"expected original term 1, got %d",
			entry.Term,
		)
	}

	if entry.Value != "FREE" {
		t.Fatalf(
			"expected original value FREE, got %s",
			entry.Value,
		)
	}
}
func TestStateMachineAllocateSeat(t *testing.T) {
	dir := t.TempDir()

	db, err := lsm.OpenDB(dir)
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()

	sm := NewStateMachine(db)

	err = sm.Apply(LogEntry{
		Term:    1,
		Command: "PUT",
		Key:     "seat/ROOM101/A01",
		Value:   "FREE",
	})

	if err != nil {
		t.Fatal(err)
	}

	err = sm.Apply(LogEntry{
		Term:    1,
		Command: "ALLOCATE_SEAT",
		Key:     "seat/ROOM101/A01",
		Value:   "STU123",
	})

	if err != nil {
		t.Fatal(err)
	}

	value, exists := db.Get("seat/ROOM101/A01")

	if !exists {
		t.Fatal("expected seat to exist")
	}

	if value != "ALLOCATED:STU123" {
		t.Fatalf(
			"expected ALLOCATED:STU123, got %s",
			value,
		)
	}
}
func TestStateMachinePreventsDoubleAllocation(t *testing.T) {
	dir := t.TempDir()

	db, err := lsm.OpenDB(dir)
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()

	sm := NewStateMachine(db)

	err = sm.Apply(LogEntry{
		Term:    1,
		Command: "PUT",
		Key:     "seat/ROOM101/A01",
		Value:   "FREE",
	})

	if err != nil {
		t.Fatal(err)
	}

	err = sm.Apply(LogEntry{
		Term:    1,
		Command: "ALLOCATE_SEAT",
		Key:     "seat/ROOM101/A01",
		Value:   "STU123",
	})

	if err != nil {
		t.Fatal(err)
	}

	err = sm.Apply(LogEntry{
		Term:    1,
		Command: "ALLOCATE_SEAT",
		Key:     "seat/ROOM101/A01",
		Value:   "STU456",
	})

	if err != nil {
		t.Fatal(err)
	}

	value, exists := db.Get("seat/ROOM101/A01")

	if !exists {
		t.Fatal("expected seat to exist")
	}

	if value != "ALLOCATED:STU123" {
		t.Fatalf(
			"expected first allocation to remain STU123, got %s",
			value,
		)
	}
}
func TestNodeSetStateMachine(t *testing.T) {
	dir := t.TempDir()

	db, err := lsm.OpenDB(dir)
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()

	sm := NewStateMachine(db)

	node := NewNode("node1")
	node.SetStateMachine(sm)

	if node.StateMachine != sm {
		t.Fatal("expected state machine to be attached to node")
	}
}
func TestApplyCommittedWritesToLSM(t *testing.T) {
	dir := t.TempDir()

	db, err := lsm.OpenDB(dir)
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()

	sm := NewStateMachine(db)

	node := NewNode("node1")
	node.SetStateMachine(sm)

	node.CurrentTerm = 1

	node.Log = append(node.Log, LogEntry{
		Term:    1,
		Command: "PUT",
		Key:     "seat/ROOM101/A01",
		Value:   "FREE",
	})

	node.CommitIndex = 1

	node.ApplyCommitted()

	value, exists := db.Get("seat/ROOM101/A01")

	if !exists {
		t.Fatal("expected committed entry to exist in LSM")
	}

	if value != "FREE" {
		t.Fatalf(
			"expected FREE, got %s",
			value,
		)
	}

	if node.LastApplied != 1 {
		t.Fatalf(
			"expected LastApplied 1, got %d",
			node.LastApplied,
		)
	}
}
func TestApplyCommittedAllocationToLSM(t *testing.T) {
	dir := t.TempDir()

	db, err := lsm.OpenDB(dir)
	if err != nil {
		t.Fatal(err)
	}
	defer db.Close()

	sm := NewStateMachine(db)

	node := NewNode("node1")
	node.SetStateMachine(sm)

	node.CurrentTerm = 1

	node.Log = append(node.Log,
		LogEntry{
			Term:    1,
			Command: "PUT",
			Key:     "seat/ROOM101/A01",
			Value:   "FREE",
		},
		LogEntry{
			Term:    1,
			Command: "ALLOCATE_SEAT",
			Key:     "seat/ROOM101/A01",
			Value:   "STU123",
		},
	)

	node.CommitIndex = 2

	node.ApplyCommitted()

	value, exists := db.Get("seat/ROOM101/A01")

	if !exists {
		t.Fatal("expected seat to exist in LSM")
	}

	if value != "ALLOCATED:STU123" {
		t.Fatalf(
			"expected ALLOCATED:STU123, got %s",
			value,
		)
	}

	if node.LastApplied != 2 {
		t.Fatalf(
			"expected LastApplied 2, got %d",
			node.LastApplied,
		)
	}
}
func TestServicePut(t *testing.T) {
	tc := newTestCluster(t)

	leader := tc.cluster.Nodes["node1"]

	leader.StartElection()
	leader.BecomeLeader()

	service := NewService(tc.cluster, "node1")

	success := service.Put(
		"seat/ROOM101/A01",
		"FREE",
	)

	if !success {
		t.Fatal("expected PUT to succeed")
	}

	if leader.CommitIndex != 1 {
		t.Fatalf(
			"expected CommitIndex 1, got %d",
			leader.CommitIndex,
		)
	}

	for id := range tc.cluster.Nodes {
		value, exists := tc.dbs[id].Get(
			"seat/ROOM101/A01",
		)

		if !exists {
			t.Fatalf(
				"%s: expected key to exist",
				id,
			)
		}

		if value != "FREE" {
			t.Fatalf(
				"%s: expected FREE, got %s",
				id,
				value,
			)
		}
	}
}

type testCluster struct {
	cluster *Cluster
	dbs     map[string]*lsm.DB
}

func newTestCluster(t *testing.T) *testCluster {
	t.Helper()

	cluster := NewCluster([]string{
		"node1",
		"node2",
		"node3",
	})

	dbs := make(map[string]*lsm.DB)

	for id, node := range cluster.Nodes {
		dir := t.TempDir()

		db, err := lsm.OpenDB(dir)
		if err != nil {
			t.Fatal(err)
		}

		dbs[id] = db
		node.SetStateMachine(NewStateMachine(db))
	}

	t.Cleanup(func() {
		for _, db := range dbs {
			_ = db.Close()
		}
	})

	return &testCluster{
		cluster: cluster,
		dbs:     dbs,
	}
}
func TestServiceAllocate(t *testing.T) {
	tc := newTestCluster(t)

	leader := tc.cluster.Nodes["node1"]

	leader.StartElection()
	leader.BecomeLeader()

	// Create the seat as FREE on every node.
	for id := range tc.cluster.Nodes {
		err := tc.dbs[id].Put(
			"seat/ROOM101/A01",
			"FREE",
		)
		if err != nil {
			t.Fatal(err)
		}
	}

	service := NewService(tc.cluster, "node1")

	success := service.Allocate(
		"seat/ROOM101/A01",
		"STU123",
	)

	if !success {
		t.Fatal("expected allocation to succeed")
	}

	for id := range tc.cluster.Nodes {
		value, exists := tc.dbs[id].Get(
			"seat/ROOM101/A01",
		)

		if !exists {
			t.Fatalf(
				"%s: expected seat to exist",
				id,
			)
		}

		if value != "ALLOCATED:STU123" {
			t.Fatalf(
				"%s: expected ALLOCATED:STU123, got %s",
				id,
				value,
			)
		}
	}
}
func TestServiceGet(t *testing.T) {
	tc := newTestCluster(t)

	leader := tc.cluster.Nodes["node1"]

	leader.StartElection()
	leader.BecomeLeader()

	service := NewService(tc.cluster, "node1")

	success := service.Put(
		"seat/ROOM101/A01",
		"FREE",
	)

	if !success {
		t.Fatal("expected PUT to succeed")
	}

	value, exists := service.Get(
		"seat/ROOM101/A01",
	)

	if !exists {
		t.Fatal("expected key to exist")
	}

	if value != "FREE" {
		t.Fatalf(
			"expected FREE, got %s",
			value,
		)
	}
}
func TestServiceDelete(t *testing.T) {
	tc := newTestCluster(t)

	leader := tc.cluster.Nodes["node1"]

	leader.StartElection()
	leader.BecomeLeader()

	service := NewService(tc.cluster, "node1")

	success := service.Put(
		"seat/ROOM101/A01",
		"FREE",
	)

	if !success {
		t.Fatal("expected PUT to succeed")
	}

	value, exists := service.Get(
		"seat/ROOM101/A01",
	)

	if !exists {
		t.Fatal("expected key to exist before DELETE")
	}

	if value != "FREE" {
		t.Fatalf(
			"expected FREE before DELETE, got %s",
			value,
		)
	}

	success = service.Delete(
		"seat/ROOM101/A01",
	)

	if !success {
		t.Fatal("expected DELETE to succeed")
	}

	_, exists = service.Get(
		"seat/ROOM101/A01",
	)

	if exists {
		t.Fatal("expected key to be deleted")
	}
}
func TestAppendEntriesReplacesConflictingEntry(t *testing.T) {
	follower := NewNode("node2")

	follower.CurrentTerm = 3

	follower.Log = []LogEntry{
		{
			Term:    1,
			Command: "PUT",
			Key:     "seat/A01",
			Value:   "FREE",
		},
		{
			Term:    2,
			Command: "PUT",
			Key:     "seat/A02",
			Value:   "OLD",
		},
	}

	response := follower.AppendEntries(
		AppendEntriesRequest{
			Term:         3,
			LeaderID:     "node1",
			PrevLogIndex: 0,
			PrevLogTerm:  1,
			Entries: []LogEntry{
				{
					Term:    3,
					Command: "PUT",
					Key:     "seat/A02",
					Value:   "NEW",
				},
			},
			LeaderCommit: 0,
		},
	)

	if !response.Success {
		t.Fatal("expected AppendEntries to succeed")
	}

	if len(follower.Log) != 2 {
		t.Fatalf(
			"expected 2 log entries, got %d",
			len(follower.Log),
		)
	}

	if follower.Log[1].Term != 3 {
		t.Fatalf(
			"expected conflicting entry to have term 3, got %d",
			follower.Log[1].Term,
		)
	}

	if follower.Log[1].Value != "NEW" {
		t.Fatalf(
			"expected conflicting entry to be replaced with NEW, got %s",
			follower.Log[1].Value,
		)
	}
}
func TestRequestVoteRejectsOutdatedCandidateLog(t *testing.T) {
	node := NewNode("node1")

	node.CurrentTerm = 3

	node.Log = []LogEntry{
		{
			Term:    1,
			Command: "PUT",
			Key:     "seat/A01",
			Value:   "FREE",
		},
		{
			Term:    3,
			Command: "PUT",
			Key:     "seat/A02",
			Value:   "FREE",
		},
	}

	response := node.RequestVote(
		RequestVoteRequest{
			Term:         4,
			CandidateID:  "node2",
			LastLogIndex: 0,
			LastLogTerm:  1,
		},
	)

	if response.VoteGranted {
		t.Fatal("expected vote to be rejected for outdated candidate log")
	}

	if response.Term != 4 {
		t.Fatalf(
			"expected term 4, got %d",
			response.Term,
		)
	}
}
func TestClusterReplicationTracksFollowerProgress(t *testing.T) {
	test := newTestCluster(t)

	if !test.cluster.ElectLeader("node1") {
		t.Fatal("expected node1 to become leader")
	}

	entry := LogEntry{
		Command: "PUT",
		Key:     "seat/ROOM101/A01",
		Value:   "FREE",
	}

	if !test.cluster.Replicate("node1", entry) {
		t.Fatal("expected replication to succeed")
	}

	leaderIndex := uint64(len(test.cluster.Nodes["node1"].Log))

	for _, followerID := range []string{"node2", "node3"} {
		if test.cluster.matchIndex[followerID] != leaderIndex-1 {
			t.Fatalf(
				"expected %s matchIndex %d, got %d",
				followerID,
				leaderIndex-1,
				test.cluster.matchIndex[followerID],
			)
		}

		if test.cluster.nextIndex[followerID] != leaderIndex {
			t.Fatalf(
				"expected %s nextIndex %d, got %d",
				followerID,
				leaderIndex,
				test.cluster.nextIndex[followerID],
			)
		}
	}
}
func TestFollowerCatchUpUsingNextIndex(t *testing.T) {
	test := newTestCluster(t)

	if !test.cluster.ElectLeader("node1") {
		t.Fatal("expected node1 to become leader")
	}

	leader := test.cluster.Nodes["node1"]
	follower := test.cluster.Nodes["node2"]

	// First entry.
	firstEntry := LogEntry{
		Command: "PUT",
		Key:     "seat/ROOM101/A01",
		Value:   "FREE",
	}

	if !test.cluster.Replicate("node1", firstEntry) {
		t.Fatal("expected first replication to succeed")
	}

	// Simulate node2 falling behind.
	follower.mu.Lock()

	if len(follower.Log) > 0 {
		follower.Log = follower.Log[:0]
	}

	follower.CommitIndex = 0
	follower.LastApplied = 0

	follower.mu.Unlock()

	test.cluster.nextIndex["node2"] = 0
	test.cluster.matchIndex["node2"] = 0

	// Second entry.
	secondEntry := LogEntry{
		Command: "PUT",
		Key:     "seat/ROOM101/A02",
		Value:   "FREE",
	}

	if !test.cluster.Replicate("node1", secondEntry) {
		t.Fatal("expected second replication to succeed")
	}

	leader.mu.Lock()
	leaderLogLength := len(leader.Log)
	leader.mu.Unlock()

	follower.mu.Lock()
	followerLogLength := len(follower.Log)
	follower.mu.Unlock()

	if followerLogLength != leaderLogLength {
		t.Fatalf(
			"expected follower log length %d, got %d",
			leaderLogLength,
			followerLogLength,
		)
	}

	if test.cluster.nextIndex["node2"] != uint64(leaderLogLength) {
		t.Fatalf(
			"expected node2 nextIndex %d, got %d",
			leaderLogLength,
			test.cluster.nextIndex["node2"],
		)
	}

	if test.cluster.matchIndex["node2"] != uint64(leaderLogLength-1) {
		t.Fatalf(
			"expected node2 matchIndex %d, got %d",
			leaderLogLength-1,
			test.cluster.matchIndex["node2"],
		)
	}
}
func TestSendHeartbeatCatchesUpFollower(t *testing.T) {
	test := newTestCluster(t)

	if !test.cluster.ElectLeader("node1") {
		t.Fatal("expected node1 to become leader")
	}

	leader := test.cluster.Nodes["node1"]
	follower := test.cluster.Nodes["node2"]

	// Add two entries to the leader.
	leader.mu.Lock()

	leader.Log = append(
		leader.Log,
		LogEntry{
			Term:    leader.CurrentTerm,
			Command: "PUT",
			Key:     "seat/ROOM101/A01",
			Value:   "FREE",
		},
		LogEntry{
			Term:    leader.CurrentTerm,
			Command: "PUT",
			Key:     "seat/ROOM101/A02",
			Value:   "FREE",
		},
	)

	leader.mu.Unlock()

	// Simulate follower being completely behind.
	follower.mu.Lock()
	follower.Log = nil
	follower.CommitIndex = 0
	follower.LastApplied = 0
	follower.mu.Unlock()

	test.cluster.nextIndex["node2"] = 0
	test.cluster.matchIndex["node2"] = 0

	success := test.cluster.SendHeartbeat(
		"node1",
		"node2",
	)

	if !success {
		t.Fatal("expected heartbeat replication to succeed")
	}

	if len(follower.Log) != len(leader.Log) {
		t.Fatalf(
			"expected follower log length %d, got %d",
			len(leader.Log),
			len(follower.Log),
		)
	}

	if test.cluster.nextIndex["node2"] != uint64(len(leader.Log)) {
		t.Fatalf(
			"expected nextIndex %d, got %d",
			len(leader.Log),
			test.cluster.nextIndex["node2"],
		)
	}

	if test.cluster.matchIndex["node2"] != uint64(len(leader.Log)-1) {
		t.Fatalf(
			"expected matchIndex %d, got %d",
			len(leader.Log)-1,
			test.cluster.matchIndex["node2"],
		)
	}
}
func TestPersistentStateSaveAndLoad(t *testing.T) {
	path := t.TempDir() + "/raft-state.json"

	state := PersistentState{
		CurrentTerm: 5,
		VotedFor:    "node2",
		Log: []LogEntry{
			{
				Term:    5,
				Command: "PUT",
				Key:     "seat/ROOM101/A01",
				Value:   "FREE",
			},
		},
	}

	if err := SavePersistentState(path, state); err != nil {
		t.Fatalf(
			"failed to save persistent state: %v",
			err,
		)
	}

	loaded, err := LoadPersistentState(path)
	if err != nil {
		t.Fatalf(
			"failed to load persistent state: %v",
			err,
		)
	}

	if loaded.CurrentTerm != state.CurrentTerm {
		t.Fatalf(
			"expected term %d, got %d",
			state.CurrentTerm,
			loaded.CurrentTerm,
		)
	}

	if loaded.VotedFor != state.VotedFor {
		t.Fatalf(
			"expected VotedFor %s, got %s",
			state.VotedFor,
			loaded.VotedFor,
		)
	}

	if len(loaded.Log) != 1 {
		t.Fatalf(
			"expected 1 log entry, got %d",
			len(loaded.Log),
		)
	}

	if loaded.Log[0].Value != "FREE" {
		t.Fatalf(
			"expected FREE, got %s",
			loaded.Log[0].Value,
		)
	}
}
func TestNodePersistentStateRecovery(t *testing.T) {
	path := t.TempDir() + "/node-state.json"

	node := NewNode("node1")

	if err := node.SetPersistencePath(path); err != nil {
		t.Fatalf(
			"failed to set persistence path: %v",
			err,
		)
	}

	node.StartElection()

	node.AppendEntry(
		"PUT",
		"seat/ROOM101/A01",
		"FREE",
	)

	node.mu.Lock()
	expectedTerm := node.CurrentTerm
	expectedVote := node.VotedFor
	expectedLogLength := len(node.Log)
	expectedLogValue := node.Log[0].Value
	node.mu.Unlock()

	restartedNode := NewNode("node1")

	if err := restartedNode.SetPersistencePath(path); err != nil {
		t.Fatalf(
			"failed to set persistence path for restarted node: %v",
			err,
		)
	}

	if err := restartedNode.LoadPersistentState(); err != nil {
		t.Fatalf(
			"failed to load persistent state: %v",
			err,
		)
	}

	if restartedNode.CurrentTerm != expectedTerm {
		t.Fatalf(
			"expected term %d, got %d",
			expectedTerm,
			restartedNode.CurrentTerm,
		)
	}

	if restartedNode.VotedFor != expectedVote {
		t.Fatalf(
			"expected vote %s, got %s",
			expectedVote,
			restartedNode.VotedFor,
		)
	}

	if len(restartedNode.Log) != expectedLogLength {
		t.Fatalf(
			"expected log length %d, got %d",
			expectedLogLength,
			len(restartedNode.Log),
		)
	}

	if restartedNode.Log[0].Value != expectedLogValue {
		t.Fatalf(
			"expected log value %s, got %s",
			expectedLogValue,
			restartedNode.Log[0].Value,
		)
	}
}
func TestClusterReplicateWithOneFollowerUnavailable(t *testing.T) {
	test := newTestCluster(t)

	cluster := test.cluster

	if !cluster.ElectLeader("node1") {
		t.Fatal("expected node1 to become leader")
	}

	// Simulate node3 being unavailable by removing it
	// from the cluster's active node set.
	delete(cluster.Nodes, "node3")

	success := cluster.Replicate(
		"node1",
		LogEntry{
			Command: "PUT",
			Key:     "seat/ROOM101/A02",
			Value:   "FREE",
		},
	)

	if !success {
		t.Fatal("expected replication to succeed with a majority")
	}

	value, exists := test.dbs["node1"].Get("seat/ROOM101/A02")

	if !exists {
		t.Fatal("expected value to exist on leader")
	}

	if value != "FREE" {
		t.Fatalf(
			"expected FREE, got %s",
			value,
		)
	}
}
func TestClusterReplicateFailsWithoutMajority(t *testing.T) {
	test := newTestCluster(t)

	cluster := test.cluster

	if !cluster.ElectLeader("node1") {
		t.Fatal("expected node1 to become leader")
	}

	// Simulate loss of both followers.
	delete(cluster.Nodes, "node2")
	delete(cluster.Nodes, "node3")

	success := cluster.Replicate(
		"node1",
		LogEntry{
			Command: "PUT",
			Key:     "seat/ROOM101/A03",
			Value:   "FREE",
		},
	)

	if success {
		t.Fatal("expected replication to fail without a majority")
	}
}
