package raft

import "seatraft/lsm"

type StateMachine struct {
	DB *lsm.DB
}

func NewStateMachine(db *lsm.DB) *StateMachine {
	return &StateMachine{
		DB: db,
	}
}

func (sm *StateMachine) Apply(entry LogEntry) error {
	switch entry.Command {
	case "PUT":
		return sm.DB.Put(entry.Key, entry.Value)

	case "DELETE":
		return sm.DB.Delete(entry.Key)

	case "ALLOCATE_SEAT":
		value, exists := sm.DB.Get(entry.Key)

		if !exists || value != "FREE" {
			return nil
		}

		return sm.DB.Put(
			entry.Key,
			"ALLOCATED:"+entry.Value,
		)

	default:
		return nil
	}
}
