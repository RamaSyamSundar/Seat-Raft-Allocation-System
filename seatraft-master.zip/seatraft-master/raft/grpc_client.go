package raft

import (
	"context"

	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"

	pb "seatraft/proto"
)

type GRPCClient struct {
	conn   *grpc.ClientConn
	client pb.RaftClient
}

func NewGRPCClient(address string) (*GRPCClient, error) {
	conn, err := grpc.NewClient(
		address,
		grpc.WithTransportCredentials(insecure.NewCredentials()),
	)
	if err != nil {
		return nil, err
	}

	return &GRPCClient{
		conn:   conn,
		client: pb.NewRaftClient(conn),
	}, nil
}

func (c *GRPCClient) RequestVote(
	ctx context.Context,
	req RequestVoteRequest,
) (RequestVoteResponse, error) {
	response, err := c.client.RequestVote(
		ctx,
		&pb.RequestVoteRequest{
			Term:         req.Term,
			CandidateId:  req.CandidateID,
			LastLogIndex: req.LastLogIndex,
			LastLogTerm:  req.LastLogTerm,
		},
	)
	if err != nil {
		return RequestVoteResponse{}, err
	}

	return RequestVoteResponse{
		Term:        response.GetTerm(),
		VoteGranted: response.GetVoteGranted(),
	}, nil
}

func (c *GRPCClient) AppendEntries(
	ctx context.Context,
	req AppendEntriesRequest,
) (AppendEntriesResponse, error) {
	entries := make([]*pb.LogEntry, 0, len(req.Entries))

	for _, entry := range req.Entries {
		entries = append(entries, &pb.LogEntry{
			Term:    entry.Term,
			Command: entry.Command,
			Key:     entry.Key,
			Value:   entry.Value,
		})
	}

	response, err := c.client.AppendEntries(
		ctx,
		&pb.AppendEntriesRequest{
			Term:         req.Term,
			LeaderId:     req.LeaderID,
			PrevLogIndex: req.PrevLogIndex,
			PrevLogTerm:  req.PrevLogTerm,
			Entries:      entries,
			LeaderCommit: req.LeaderCommit,
		},
	)
	if err != nil {
		return AppendEntriesResponse{}, err
	}

	return AppendEntriesResponse{
		Term:    response.GetTerm(),
		Success: response.GetSuccess(),
	}, nil
}

func (c *GRPCClient) Close() error {
	return c.conn.Close()
}
