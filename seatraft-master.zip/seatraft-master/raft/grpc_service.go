package raft

import (
	"context"

	pb "seatraft/proto"
)

type GRPCService struct {
	pb.UnimplementedRaftServer
	Node *Node
}

func NewGRPCService(node *Node) *GRPCService {
	return &GRPCService{
		Node: node,
	}
}

func (s *GRPCService) RequestVote(
	ctx context.Context,
	req *pb.RequestVoteRequest,
) (*pb.RequestVoteResponse, error) {
	response := s.Node.RequestVote(
		RequestVoteRequest{
			Term:         req.GetTerm(),
			CandidateID:  req.GetCandidateId(),
			LastLogIndex: req.GetLastLogIndex(),
			LastLogTerm:  req.GetLastLogTerm(),
		},
	)

	return &pb.RequestVoteResponse{
		Term:        response.Term,
		VoteGranted: response.VoteGranted,
	}, nil
}

func (s *GRPCService) AppendEntries(
	ctx context.Context,
	req *pb.AppendEntriesRequest,
) (*pb.AppendEntriesResponse, error) {
	entries := make([]LogEntry, 0, len(req.GetEntries()))

	for _, entry := range req.GetEntries() {
		entries = append(entries, LogEntry{
			Term:    entry.GetTerm(),
			Command: entry.GetCommand(),
			Key:     entry.GetKey(),
			Value:   entry.GetValue(),
		})
	}

	response := s.Node.AppendEntries(
		AppendEntriesRequest{
			Term:         req.GetTerm(),
			LeaderID:     req.GetLeaderId(),
			PrevLogIndex: req.GetPrevLogIndex(),
			PrevLogTerm:  req.GetPrevLogTerm(),
			Entries:      entries,
			LeaderCommit: req.GetLeaderCommit(),
		},
	)

	// Apply entries when the leader's commit index advances.
	if response.Success {
		s.Node.ApplyCommitted()
	}

	return &pb.AppendEntriesResponse{
		Term:    response.Term,
		Success: response.Success,
	}, nil
}
