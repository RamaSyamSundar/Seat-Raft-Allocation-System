package raft

import "sync"

type Service struct {
	Cluster  *Cluster
	LeaderID string

	allocateMu sync.Mutex
}

func NewService(cluster *Cluster, leaderID string) *Service {
	return &Service{
		Cluster:  cluster,
		LeaderID: leaderID,
	}
}

func (s *Service) Put(key string, value string) bool {
	entry := LogEntry{
		Command: "PUT",
		Key:     key,
		Value:   value,
	}

	return s.Cluster.Replicate(
		s.LeaderID,
		entry,
	)
}

func (s *Service) Allocate(key string, studentID string) bool {
	s.allocateMu.Lock()
	defer s.allocateMu.Unlock()

	leader, exists := s.Cluster.Nodes[s.LeaderID]

	if !exists {
		return false
	}

	if leader.State != Leader {
		return false
	}

	if leader.StateMachine == nil {
		return false
	}

	// Check the current committed state before creating
	// an allocation command.
	value, exists := leader.StateMachine.DB.Get(key)

	if !exists || value != "FREE" {
		return false
	}

	entry := LogEntry{
		Command: "ALLOCATE_SEAT",
		Key:     key,
		Value:   studentID,
	}

	return s.Cluster.Replicate(
		s.LeaderID,
		entry,
	)
}

func (s *Service) Get(key string) (string, bool) {
	leader, exists := s.Cluster.Nodes[s.LeaderID]

	if !exists {
		return "", false
	}

	if leader.State != Leader {
		return "", false
	}

	if leader.StateMachine == nil {
		return "", false
	}

	return leader.StateMachine.DB.Get(key)
}

func (s *Service) Delete(key string) bool {
	entry := LogEntry{
		Command: "DELETE",
		Key:     key,
	}

	return s.Cluster.Replicate(
		s.LeaderID,
		entry,
	)
}
