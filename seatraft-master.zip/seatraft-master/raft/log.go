package raft

type LogEntry struct {
	Term    uint64
	Command string
	Key     string
	Value   string
}
