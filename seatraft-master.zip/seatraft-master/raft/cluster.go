package raft

import (
	"context"
	"fmt"
	"sync"
	"time"
)

type Cluster struct {
	mu         sync.Mutex
	Nodes      map[string]*Node
	Addresses  map[string]string
	clients    map[string]*GRPCClient
	totalNodes int
	nextIndex  map[string]uint64
	matchIndex map[string]uint64
}

func NewCluster(ids []string) *Cluster {
	nodes := make(map[string]*Node)
	addresses := make(map[string]string)
	clients := make(map[string]*GRPCClient)
	nextIndex := make(map[string]uint64)
	matchIndex := make(map[string]uint64)

	for _, id := range ids {
		nodes[id] = NewNode(id)
		addresses[id] = ""
		nextIndex[id] = 0
		matchIndex[id] = 0
	}

	return &Cluster{
		Nodes:      nodes,
		Addresses:  addresses,
		clients:    clients,
		totalNodes: len(ids),
		nextIndex:  nextIndex,
		matchIndex: matchIndex,
	}
}

func (c *Cluster) SetAddress(nodeID, address string) bool {
	c.mu.Lock()
	defer c.mu.Unlock()

	if nodeID == "" || address == "" {
		return false
	}

	// Remote peers may not have an in-process Node object.
	if _, exists := c.Nodes[nodeID]; !exists {
		c.Addresses[nodeID] = address
		c.nextIndex[nodeID] = 0
		c.matchIndex[nodeID] = 0
		c.totalNodes++
		return true
	}

	c.Addresses[nodeID] = address
	return true
}

func (c *Cluster) ConnectPeer(nodeID string) error {
	c.mu.Lock()

	address, exists := c.Addresses[nodeID]
	if !exists || address == "" {
		c.mu.Unlock()
		return fmt.Errorf("no address configured for node %s", nodeID)
	}

	if _, exists := c.clients[nodeID]; exists {
		c.mu.Unlock()
		return nil
	}

	c.mu.Unlock()

	client, err := NewGRPCClient(address)
	if err != nil {
		return err
	}

	c.mu.Lock()
	defer c.mu.Unlock()

	if _, exists := c.clients[nodeID]; exists {
		_ = client.Close()
		return nil
	}

	c.clients[nodeID] = client
	return nil
}

func (c *Cluster) ConnectRemotePeer(nodeID string) error {
	return c.ConnectPeer(nodeID)
}

func (c *Cluster) HasPeerConnection(nodeID string) bool {
	c.mu.Lock()
	defer c.mu.Unlock()

	_, exists := c.clients[nodeID]
	return exists
}

func (c *Cluster) ElectLeader(candidateID string) bool {
	c.mu.Lock()
	defer c.mu.Unlock()

	candidate, exists := c.Nodes[candidateID]
	if !exists {
		return false
	}

	candidate.StartElection()

	candidate.mu.Lock()
	candidateTerm := candidate.CurrentTerm
	lastLogIndex := uint64(0)
	lastLogTerm := uint64(0)

	if len(candidate.Log) > 0 {
		lastLogIndex = uint64(len(candidate.Log) - 1)
		lastLogTerm = candidate.Log[len(candidate.Log)-1].Term
	}
	candidate.mu.Unlock()

	votes := 1
	majority := c.totalNodes/2 + 1

	for id, peer := range c.Nodes {
		if id == candidateID {
			continue
		}

		request := RequestVoteRequest{
			Term:         candidateTerm,
			CandidateID:  candidate.ID,
			LastLogIndex: lastLogIndex,
			LastLogTerm:  lastLogTerm,
		}

		var response RequestVoteResponse

		if client, connected := c.clients[id]; connected {
			ctx, cancel := context.WithTimeout(
				context.Background(),
				2*time.Second,
			)
			result, err := client.RequestVote(ctx, request)
			cancel()

			if err != nil {
				fmt.Printf(
					"Election debug: candidate=%s peer=%s RPC error=%v\n",
					candidateID, id, err,
				)
				continue
			}
			response = result
		} else {
			if c.Addresses[id] != "" {
				continue
			}
			response = peer.RequestVote(request)
		}

		fmt.Printf(
			"Election debug: candidate=%s term=%d peer=%s responseTerm=%d voteGranted=%t\n",
			candidateID, candidateTerm, id,
			response.Term, response.VoteGranted,
		)

		if response.Term > candidateTerm {
			candidate.mu.Lock()
			if response.Term > candidate.CurrentTerm {
				candidate.CurrentTerm = response.Term
				candidate.State = Follower
				candidate.VotedFor = ""
				_ = candidate.savePersistentStateLocked()
			}
			candidate.mu.Unlock()
			return false
		}

		if response.VoteGranted {
			votes++
		}
	}

	fmt.Printf(
		"Election result: candidate=%s votes=%d required=%d\n",
		candidateID, votes, majority,
	)

	if votes < majority {
		return false
	}

	candidate.BecomeLeader()

	candidate.mu.Lock()
	next := uint64(len(candidate.Log))
	candidate.mu.Unlock()

	for id := range c.Nodes {
		c.nextIndex[id] = next
		if id == candidateID {
			c.matchIndex[id] = next
		} else {
			c.matchIndex[id] = 0
		}
	}

	return true
}

func (c *Cluster) Replicate(leaderID string, entry LogEntry) bool {
	c.mu.Lock()
	defer c.mu.Unlock()

	leader, exists := c.Nodes[leaderID]
	if !exists {
		return false
	}

	leader.mu.Lock()
	if leader.State != Leader {
		leader.mu.Unlock()
		return false
	}

	entry.Term = leader.CurrentTerm
	leader.Log = append(leader.Log, entry)

	if err := leader.savePersistentStateLocked(); err != nil {
		leader.Log = leader.Log[:len(leader.Log)-1]
		leader.mu.Unlock()
		return false
	}

	entryIndex := uint64(len(leader.Log) - 1)
	currentTerm := leader.CurrentTerm
	leader.mu.Unlock()

	successCount := 1

	for id, peer := range c.Nodes {
		if id == leaderID {
			continue
		}

		leader.mu.Lock()
		next := c.nextIndex[id]
		if next > entryIndex {
			next = entryIndex
		}
		if next > uint64(len(leader.Log)) {
			next = uint64(len(leader.Log))
		}

		prevIndex := uint64(0)
		prevTerm := uint64(0)
		if next > 0 {
			prevIndex = next - 1
			prevTerm = leader.Log[prevIndex].Term
		}
		entries := append([]LogEntry(nil), leader.Log[next:]...)
		leader.mu.Unlock()

		request := AppendEntriesRequest{
			Term:         currentTerm,
			LeaderID:     leader.ID,
			PrevLogIndex: prevIndex,
			PrevLogTerm:  prevTerm,
			Entries:      entries,
			LeaderCommit: 0,
		}

		var response AppendEntriesResponse

		if client, connected := c.clients[id]; connected {
			ctx, cancel := context.WithTimeout(
				context.Background(),
				2*time.Second,
			)
			result, err := client.AppendEntries(ctx, request)
			cancel()

			if err != nil {
				fmt.Printf(
					"Replication debug: leader=%s peer=%s RPC error=%v\n",
					leaderID, id, err,
				)
				continue
			}
			response = result
		} else {
			if c.Addresses[id] != "" {
				continue
			}
			response = peer.AppendEntries(request)
		}

		if response.Term > currentTerm {
			leader.mu.Lock()
			if response.Term > leader.CurrentTerm {
				leader.CurrentTerm = response.Term
				leader.State = Follower
				leader.VotedFor = ""
				_ = leader.savePersistentStateLocked()
			}
			leader.mu.Unlock()
			return false
		}

		if response.Success {
			leader.mu.Lock()
			length := uint64(len(leader.Log))
			leader.mu.Unlock()

			c.matchIndex[id] = length - 1
			c.nextIndex[id] = length
			successCount++
		} else if c.nextIndex[id] > 0 {
			c.nextIndex[id]--
		}
	}

	majority := c.totalNodes/2 + 1
	if successCount < majority {
		fmt.Printf(
			"Replication failed: leader=%s acknowledgements=%d required=%d\n",
			leaderID, successCount, majority,
		)
		return false
	}

	leader.mu.Lock()
	leader.CommitIndex = uint64(len(leader.Log))
	commitIndex := leader.CommitIndex
	lastIndex := uint64(0)
	lastTerm := uint64(0)

	if len(leader.Log) > 0 {
		lastIndex = uint64(len(leader.Log) - 1)
		lastTerm = leader.Log[lastIndex].Term
	}
	leader.mu.Unlock()

	leader.ApplyCommitted()

	for id, client := range c.clients {
		if id == leaderID {
			continue
		}

		ctx, cancel := context.WithTimeout(
			context.Background(),
			2*time.Second,
		)
		_, err := client.AppendEntries(
			ctx,
			AppendEntriesRequest{
				Term:         currentTerm,
				LeaderID:     leader.ID,
				PrevLogIndex: lastIndex,
				PrevLogTerm:  lastTerm,
				LeaderCommit: commitIndex,
			},
		)
		cancel()

		if err != nil {
			fmt.Printf(
				"Warning: failed to notify follower %s of commit: %v\n",
				id, err,
			)
		}
	}

	for id, peer := range c.Nodes {
		if id == leaderID || c.Addresses[id] != "" {
			continue
		}

		peer.mu.Lock()
		if commitIndex > peer.CommitIndex {
			peer.CommitIndex = commitIndex
			if peer.CommitIndex > uint64(len(peer.Log)) {
				peer.CommitIndex = uint64(len(peer.Log))
			}
		}
		peer.mu.Unlock()

		peer.ApplyCommitted()
	}

	return true
}
