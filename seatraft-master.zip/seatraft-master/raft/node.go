package raft

import (
	"os"
	"sync"

	"seatraft/kv"
)

type State int

const (
	Follower State = iota
	Candidate
	Leader
)

type Node struct {
	mu sync.Mutex

	ID          string
	State       State
	CurrentTerm uint64
	VotedFor    string

	Log         []LogEntry
	CommitIndex uint64
	LastApplied uint64

	Store        *kv.Store
	StateMachine *StateMachine

	PersistencePath string
}

func NewNode(id string) *Node {
	return &Node{
		ID:              id,
		State:           Follower,
		CurrentTerm:     0,
		VotedFor:        "",
		Log:             make([]LogEntry, 0),
		CommitIndex:     0,
		LastApplied:     0,
		Store:           kv.NewStore(),
		PersistencePath: "",
	}
}

func (n *Node) SetStateMachine(sm *StateMachine) {
	n.mu.Lock()
	defer n.mu.Unlock()
	n.StateMachine = sm
}

func (n *Node) RequestVote(req RequestVoteRequest) RequestVoteResponse {
	n.mu.Lock()
	defer n.mu.Unlock()

	if req.Term < n.CurrentTerm {
		return RequestVoteResponse{Term: n.CurrentTerm}
	}

	if req.Term > n.CurrentTerm {
		n.CurrentTerm = req.Term
		n.State = Follower
		n.VotedFor = ""

		if err := n.savePersistentStateLocked(); err != nil {
			return RequestVoteResponse{Term: n.CurrentTerm}
		}
	}

	var lastLogIndex uint64
	var lastLogTerm uint64

	if len(n.Log) > 0 {
		lastLogIndex = uint64(len(n.Log) - 1)
		lastLogTerm = n.Log[len(n.Log)-1].Term
	}

	logUpToDate := req.LastLogTerm > lastLogTerm ||
		(req.LastLogTerm == lastLogTerm &&
			req.LastLogIndex >= lastLogIndex)

	if !logUpToDate {
		return RequestVoteResponse{
			Term:        n.CurrentTerm,
			VoteGranted: false,
		}
	}

	if n.VotedFor == "" || n.VotedFor == req.CandidateID {
		n.VotedFor = req.CandidateID

		if err := n.savePersistentStateLocked(); err != nil {
			return RequestVoteResponse{Term: n.CurrentTerm}
		}

		return RequestVoteResponse{
			Term:        n.CurrentTerm,
			VoteGranted: true,
		}
	}

	return RequestVoteResponse{
		Term:        n.CurrentTerm,
		VoteGranted: false,
	}
}

func (n *Node) StartElection() {
	n.mu.Lock()
	defer n.mu.Unlock()

	n.CurrentTerm++
	n.State = Candidate
	n.VotedFor = n.ID
	_ = n.savePersistentStateLocked()
}

func (n *Node) BecomeLeader() {
	n.mu.Lock()
	defer n.mu.Unlock()
	n.State = Leader
}

func (n *Node) AppendEntry(command, key, value string) {
	n.mu.Lock()
	defer n.mu.Unlock()

	n.Log = append(n.Log, LogEntry{
		Term:    n.CurrentTerm,
		Command: command,
		Key:     key,
		Value:   value,
	})

	_ = n.savePersistentStateLocked()
}

func (n *Node) AppendEntries(req AppendEntriesRequest) AppendEntriesResponse {
	n.mu.Lock()
	defer n.mu.Unlock()

	if req.Term < n.CurrentTerm {
		return AppendEntriesResponse{
			Term:    n.CurrentTerm,
			Success: false,
		}
	}

	if req.Term > n.CurrentTerm {
		n.CurrentTerm = req.Term
		n.VotedFor = ""
	}

	// Receiving AppendEntries establishes a follower state.
	// Preserve VotedFor when the term has not changed.
	n.State = Follower

	// Validate the previous log position for both writes and heartbeats.
	if req.PrevLogIndex > 0 || req.PrevLogTerm > 0 {
		if req.PrevLogIndex >= uint64(len(n.Log)) {
			return AppendEntriesResponse{
				Term:    n.CurrentTerm,
				Success: false,
			}
		}

		if n.Log[req.PrevLogIndex].Term != req.PrevLogTerm {
			return AppendEntriesResponse{
				Term:    n.CurrentTerm,
				Success: false,
			}
		}
	}

	insertIndex := req.PrevLogIndex + 1

	for i, incoming := range req.Entries {
		index := insertIndex + uint64(i)

		if index < uint64(len(n.Log)) {
			if n.Log[index].Term != incoming.Term {
				if index < n.CommitIndex {
					return AppendEntriesResponse{
						Term:    n.CurrentTerm,
						Success: false,
					}
				}

				n.Log = n.Log[:index]
				n.Log = append(n.Log, req.Entries[i:]...)
				break
			}

			continue
		}

		n.Log = append(n.Log, req.Entries[i:]...)
		break
	}

	if err := n.savePersistentStateLocked(); err != nil {
		return AppendEntriesResponse{
			Term:    n.CurrentTerm,
			Success: false,
		}
	}

	if req.LeaderCommit > n.CommitIndex {
		n.CommitIndex = req.LeaderCommit
		if n.CommitIndex > uint64(len(n.Log)) {
			n.CommitIndex = uint64(len(n.Log))
		}
	}

	return AppendEntriesResponse{
		Term:    n.CurrentTerm,
		Success: true,
	}
}

func (n *Node) ApplyCommitted() {
	n.mu.Lock()
	defer n.mu.Unlock()

	for n.LastApplied < n.CommitIndex {
		entry := n.Log[n.LastApplied]

		if n.StateMachine != nil {
			_ = n.StateMachine.Apply(entry)
		}

		n.LastApplied++
	}
}

func (n *Node) Heartbeat() AppendEntriesRequest {
	n.mu.Lock()
	defer n.mu.Unlock()

	var prevLogIndex uint64
	var prevLogTerm uint64

	if len(n.Log) > 0 {
		prevLogIndex = uint64(len(n.Log) - 1)
		prevLogTerm = n.Log[len(n.Log)-1].Term
	}

	return AppendEntriesRequest{
		Term:         n.CurrentTerm,
		LeaderID:     n.ID,
		PrevLogIndex: prevLogIndex,
		PrevLogTerm:  prevLogTerm,
		Entries:      nil,
		LeaderCommit: n.CommitIndex,
	}
}

// SendHeartbeat replicates pending entries and the commit index to a
// follower in the same process. Remote Kubernetes peers require gRPC.
func (c *Cluster) SendHeartbeat(leaderID, followerID string) bool {
	c.mu.Lock()
	defer c.mu.Unlock()

	leader, leaderExists := c.Nodes[leaderID]
	follower, followerExists := c.Nodes[followerID]
	if !leaderExists || !followerExists {
		return false
	}

	leader.mu.Lock()
	if leader.State != Leader {
		leader.mu.Unlock()
		return false
	}

	logLength := uint64(len(leader.Log))
	next := c.nextIndex[followerID]
	if next > logLength {
		next = logLength
	}

	var prevLogIndex uint64
	var prevLogTerm uint64
	if next > 0 {
		prevLogIndex = next - 1
		prevLogTerm = leader.Log[prevLogIndex].Term
	}

	entries := append([]LogEntry(nil), leader.Log[next:]...)
	term := leader.CurrentTerm
	commitIndex := leader.CommitIndex
	leader.mu.Unlock()

	response := follower.AppendEntries(AppendEntriesRequest{
		Term:         term,
		LeaderID:     leaderID,
		PrevLogIndex: prevLogIndex,
		PrevLogTerm:  prevLogTerm,
		Entries:      entries,
		LeaderCommit: commitIndex,
	})

	if response.Term > term {
		leader.mu.Lock()
		if response.Term > leader.CurrentTerm {
			leader.CurrentTerm = response.Term
			leader.State = Follower
			leader.VotedFor = ""
			_ = leader.savePersistentStateLocked()
		}
		leader.mu.Unlock()
		return false
	}

	if !response.Success {
		if c.nextIndex[followerID] > 0 {
			c.nextIndex[followerID]--
		}
		return false
	}

	if logLength > 0 {
		c.matchIndex[followerID] = logLength - 1
	} else {
		c.matchIndex[followerID] = 0
	}
	c.nextIndex[followerID] = logLength

	return true
}

func (n *Node) SetPersistencePath(path string) error {
	n.mu.Lock()
	defer n.mu.Unlock()

	n.PersistencePath = path
	return nil
}

func (n *Node) savePersistentStateLocked() error {
	if n.PersistencePath == "" {
		return nil
	}

	return SavePersistentState(
		n.PersistencePath,
		PersistentState{
			CurrentTerm: n.CurrentTerm,
			VotedFor:    n.VotedFor,
			Log:         append([]LogEntry(nil), n.Log...),
		},
	)
}

func (n *Node) LoadPersistentState() error {
	n.mu.Lock()
	defer n.mu.Unlock()

	if n.PersistencePath == "" {
		return nil
	}

	state, err := LoadPersistentState(n.PersistencePath)
	if err != nil {
		if os.IsNotExist(err) {
			return nil
		}
		return err
	}

	n.CurrentTerm = state.CurrentTerm
	n.VotedFor = state.VotedFor
	n.Log = append([]LogEntry(nil), state.Log...)

	return nil
}
