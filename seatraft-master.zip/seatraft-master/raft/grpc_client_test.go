package raft

import (
	"context"
	"net"
	"testing"
	"time"

	"google.golang.org/grpc"

	pb "seatraft/proto"
)

func TestGRPCClientRequestVote(t *testing.T) {
	node := NewNode("node2")

	server := grpc.NewServer()

	raftServer := NewGRPCService(node)
	pb.RegisterRaftServer(server, raftServer)

	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}

	go func() {
		_ = server.Serve(listener)
	}()

	defer server.Stop()
	defer listener.Close()

	client, err := NewGRPCClient(listener.Addr().String())
	if err != nil {
		t.Fatal(err)
	}
	defer client.Close()

	ctx, cancel := context.WithTimeout(
		context.Background(),
		2*time.Second,
	)
	defer cancel()

	response, err := client.RequestVote(
		ctx,
		RequestVoteRequest{
			Term:         1,
			CandidateID:  "node1",
			LastLogIndex: 0,
			LastLogTerm:  0,
		},
	)

	if err != nil {
		t.Fatal(err)
	}

	if !response.VoteGranted {
		t.Fatal("expected vote to be granted")
	}

	if response.Term != 1 {
		t.Fatalf(
			"expected term 1, got %d",
			response.Term,
		)
	}
}

func TestGRPCClientAppendEntries(t *testing.T) {
	node := NewNode("node2")

	server := grpc.NewServer()

	raftServer := NewGRPCService(node)
	pb.RegisterRaftServer(server, raftServer)

	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatal(err)
	}

	go func() {
		_ = server.Serve(listener)
	}()

	defer server.Stop()
	defer listener.Close()

	client, err := NewGRPCClient(listener.Addr().String())
	if err != nil {
		t.Fatal(err)
	}
	defer client.Close()

	ctx, cancel := context.WithTimeout(
		context.Background(),
		2*time.Second,
	)
	defer cancel()

	response, err := client.AppendEntries(
		ctx,
		AppendEntriesRequest{
			Term:         1,
			LeaderID:     "node1",
			PrevLogIndex: 0,
			PrevLogTerm:  0,
			Entries: []LogEntry{
				{
					Term:    1,
					Command: "PUT",
					Key:     "seat/ROOM101/A01",
					Value:   "FREE",
				},
			},
			LeaderCommit: 0,
		},
	)

	if err != nil {
		t.Fatal(err)
	}

	if !response.Success {
		t.Fatal("expected AppendEntries to succeed")
	}

	if len(node.Log) != 1 {
		t.Fatalf(
			"expected 1 log entry, got %d",
			len(node.Log),
		)
	}

	if node.Log[0].Key != "seat/ROOM101/A01" {
		t.Fatalf(
			"unexpected key: %s",
			node.Log[0].Key,
		)
	}
}
func TestDistributedLeaderElectionOverGRPC(t *testing.T) {
	cluster := NewCluster([]string{
		"node1",
		"node2",
		"node3",
	})

	for _, id := range []string{"node2", "node3"} {
		remoteNode := NewNode(id)

		server := grpc.NewServer()
		pb.RegisterRaftServer(
			server,
			NewGRPCService(remoteNode),
		)

		listener, err := net.Listen("tcp", "127.0.0.1:0")
		if err != nil {
			t.Fatal(err)
		}

		t.Cleanup(func() {
			server.Stop()
			listener.Close()
		})

		go func() {
			_ = server.Serve(listener)
		}()

		cluster.SetAddress(id, listener.Addr().String())

		if err := cluster.ConnectPeer(id); err != nil {
			t.Fatalf("failed to connect to %s: %v", id, err)
		}
	}

	if !cluster.ElectLeader("node1") {
		t.Fatal("node1 failed to win the election")
	}

	leader := cluster.Nodes["node1"]

	if leader.State != Leader {
		t.Fatal("node1 did not become leader")
	}

	t.Log("node1 successfully won the election through gRPC")
}