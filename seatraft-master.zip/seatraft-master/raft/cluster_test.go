package raft

import (
	"net"
	"testing"

	"google.golang.org/grpc"

	pb "seatraft/proto"
)

func TestClusterConnectPeer(t *testing.T) {
	node := NewNode("node2")

	server := grpc.NewServer()
	pb.RegisterRaftServer(server, NewGRPCService(node))

	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatalf("failed to listen: %v", err)
	}
	defer listener.Close()

	go func() {
		_ = server.Serve(listener)
	}()
	defer server.Stop()

	cluster := NewCluster([]string{"node1", "node2"})

	cluster.SetAddress("node2", listener.Addr().String())

	if err := cluster.ConnectPeer("node2"); err != nil {
		t.Fatalf("failed to connect to peer: %v", err)
	}

	cluster.mu.Lock()
	_, exists := cluster.clients["node2"]
	cluster.mu.Unlock()

	if !exists {
		t.Fatal("expected gRPC client for node2")
	}
}

func TestClusterReplicateOverGRPC(t *testing.T) {
	follower := NewNode("node2")

	server := grpc.NewServer()
	pb.RegisterRaftServer(server, NewGRPCService(follower))

	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatalf("failed to listen: %v", err)
	}
	defer listener.Close()

	go func() {
		_ = server.Serve(listener)
	}()
	defer server.Stop()

	cluster := NewCluster([]string{"node1", "node2"})

	leader := cluster.Nodes["node1"]
	leader.BecomeLeader()

	cluster.SetAddress("node2", listener.Addr().String())

	if err := cluster.ConnectPeer("node2"); err != nil {
		t.Fatalf("failed to connect to follower: %v", err)
	}

	success := cluster.Replicate(
		"node1",
		LogEntry{
			Command: "PUT",
			Key:     "seat/ROOM101/A01",
			Value:   "FREE",
		},
	)

	if !success {
		t.Fatal("expected replication to succeed")
	}

	follower.mu.Lock()
	defer follower.mu.Unlock()

	if len(follower.Log) != 1 {
		t.Fatalf(
			"expected follower log length 1, got %d",
			len(follower.Log),
		)
	}

	if follower.Log[0].Key != "seat/ROOM101/A01" {
		t.Fatalf(
			"expected replicated key seat/ROOM101/A01, got %s",
			follower.Log[0].Key,
		)
	}

	if follower.Log[0].Value != "FREE" {
		t.Fatalf(
			"expected replicated value FREE, got %s",
			follower.Log[0].Value,
		)
	}
}

func TestClusterConnectRemotePeer(t *testing.T) {
	remoteNode := NewNode("node2")

	server := grpc.NewServer()
	pb.RegisterRaftServer(server, NewGRPCService(remoteNode))

	listener, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		t.Fatalf("failed to listen: %v", err)
	}
	defer listener.Close()

	go func() {
		_ = server.Serve(listener)
	}()
	defer server.Stop()

	cluster := NewCluster([]string{"node1"})

	cluster.SetAddress(
		"node2",
		listener.Addr().String(),
	)

	if err := cluster.ConnectRemotePeer("node2"); err != nil {
		t.Fatalf(
			"failed to connect to remote peer: %v",
			err,
		)
	}

	cluster.mu.Lock()
	_, exists := cluster.clients["node2"]
	cluster.mu.Unlock()

	if !exists {
		t.Fatal("expected remote gRPC client for node2")
	}
}
