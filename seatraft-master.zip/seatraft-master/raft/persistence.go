package raft

import (
	"encoding/json"
	"os"
)

type PersistentState struct {
	CurrentTerm uint64     `json:"current_term"`
	VotedFor    string     `json:"voted_for"`
	Log         []LogEntry `json:"log"`
}

func SavePersistentState(
	path string,
	state PersistentState,
) error {
	data, err := json.Marshal(state)
	if err != nil {
		return err
	}

	tempPath := path + ".tmp"

	if err := os.WriteFile(
		tempPath,
		data,
		0644,
	); err != nil {
		return err
	}

	return os.Rename(tempPath, path)
}

func LoadPersistentState(
	path string,
) (PersistentState, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		return PersistentState{}, err
	}

	var state PersistentState

	if err := json.Unmarshal(data, &state); err != nil {
		return PersistentState{}, err
	}

	return state, nil
}
