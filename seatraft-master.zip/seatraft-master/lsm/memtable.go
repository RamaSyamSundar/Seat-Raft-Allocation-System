package lsm

import "sync"

const Tombstone = "__TOMBSTONE__"

type MemTable struct {
	mu   sync.RWMutex
	data map[string]string
}

func NewMemTable() *MemTable {
	return &MemTable{
		data: make(map[string]string),
	}
}

func (m *MemTable) Put(key string, value string) {
	m.mu.Lock()
	defer m.mu.Unlock()

	m.data[key] = value
}

func (m *MemTable) Get(key string) (string, bool) {
	m.mu.RLock()
	defer m.mu.RUnlock()

	value, exists := m.data[key]
	return value, exists
}

func (m *MemTable) Delete(key string) {
	m.mu.Lock()
	defer m.mu.Unlock()

	m.data[key] = Tombstone
}
func (m *MemTable) Len() int {
	m.mu.RLock()
	defer m.mu.RUnlock()

	return len(m.data)
}
func (m *MemTable) Snapshot() map[string]string {
	m.mu.RLock()
	defer m.mu.RUnlock()

	snapshot := make(map[string]string, len(m.data))

	for key, value := range m.data {
		snapshot[key] = value
	}

	return snapshot
}
