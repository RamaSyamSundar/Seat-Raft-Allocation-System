package lsm

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

const MemTableFlushThreshold = 3

type DB struct {
	dir      string
	wal      *WAL
	memtable *MemTable
	sstables []SSTable
}

func OpenDB(dir string) (*DB, error) {
	walPath := filepath.Join(dir, "wal.log")

	wal, err := OpenWAL(walPath)
	if err != nil {
		return nil, err
	}

	memtable := NewMemTable()

	// Recover previously committed writes from the WAL.
	records, err := ReadWAL(walPath)
	if err != nil {
		wal.Close()
		return nil, err
	}

	for _, record := range records {
		parts := strings.SplitN(record, "|", 3)

		if len(parts) < 2 {
			continue
		}

		switch parts[0] {
		case "PUT":
			if len(parts) != 3 {
				continue
			}

			memtable.Put(parts[1], parts[2])

		case "DELETE":
			memtable.Delete(parts[1])
		}
	}

	// Discover existing SSTables.
	entries, err := os.ReadDir(dir)
	if err != nil {
		wal.Close()
		return nil, err
	}

	var sstables []SSTable

	for _, entry := range entries {
		if entry.IsDir() {
			continue
		}

		if strings.HasPrefix(entry.Name(), "sstable-") {
			sstables = append(
				sstables,
				SSTable{
					path: filepath.Join(dir, entry.Name()),
				},
			)
		}
	}

	return &DB{
		dir:      dir,
		wal:      wal,
		memtable: memtable,
		sstables: sstables,
	}, nil
}

func (db *DB) Put(key string, value string) error {
	record := fmt.Sprintf("PUT|%s|%s", key, value)

	if err := db.wal.Append(record); err != nil {
		return err
	}

	db.memtable.Put(key, value)

	if db.memtable.Len() >= MemTableFlushThreshold {
		if err := db.Flush(); err != nil {
			return err
		}
	}

	return nil
}

func (db *DB) Delete(key string) error {
	record := fmt.Sprintf("DELETE|%s", key)

	if err := db.wal.Append(record); err != nil {
		return err
	}

	db.memtable.Delete(key)

	return nil
}

func (db *DB) Get(key string) (string, bool) {
	// First check the MemTable.
	value, exists := db.memtable.Get(key)

	if exists {
		if value == Tombstone {
			return "", false
		}

		return value, true
	}

	// Then search SSTables from newest to oldest.
	for i := len(db.sstables) - 1; i >= 0; i-- {
		value, found, err := db.sstables[i].Get(key)

		if err != nil {
			continue
		}

		if found {
			if value == Tombstone {
				return "", false
			}

			return value, true
		}
	}

	return "", false
}

func (db *DB) Flush() error {
	oldMemTable := db.memtable

	snapshot := oldMemTable.Snapshot()

	sstablePath := filepath.Join(
		db.dir,
		fmt.Sprintf("sstable-%03d", len(db.sstables)+1),
	)

	bloom, err := WriteSSTable(sstablePath, snapshot)
	if err != nil {
		return err
	}
	db.sstables = append(
		db.sstables,
		SSTable{
			path:  sstablePath,
			bloom: bloom,
		},
	)

	// Start a fresh MemTable for new writes.
	db.memtable = NewMemTable()

	return nil
}
func (db *DB) Compact() error {
	if len(db.sstables) <= 1 {
		return nil
	}

	merged := make(map[string]string)

	// Merge from oldest to newest.
	// Newer SSTables overwrite older values.
	for _, sstable := range db.sstables {
		data, err := sstable.ReadAll()
		if err != nil {
			return err
		}

		for key, value := range data {
			merged[key] = value
		}
	}

	compactedPath := filepath.Join(
		db.dir,
		"sstable-compacted",
	)

	bloom, err := WriteSSTable(compactedPath, merged)
	if err != nil {
		return err
	}

	// Remove the old SSTables.
	for _, sstable := range db.sstables {
		if err := os.Remove(sstable.path); err != nil {
			return err
		}
	}

	// Keep only the new compacted SSTable.
	db.sstables = []SSTable{
		{
			path:  compactedPath,
			bloom: bloom,
		},
	}

	return nil
}
func (db *DB) Close() error {
	return db.wal.Close()
}
