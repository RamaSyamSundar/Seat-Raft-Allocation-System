package lsm

import (
	"path/filepath"
	"testing"
)

func TestWriteAndReadSSTable(t *testing.T) {
	dir := t.TempDir()

	path := filepath.Join(dir, "sstable-001")

	data := map[string]string{
		"seat/ROOM101/A03": "FREE",
		"seat/ROOM101/A01": "FREE",
		"seat/ROOM101/A02": "ALLOCATED:STU123",
	}

	_, err := WriteSSTable(path, data)
	if err != nil {
		t.Fatalf("failed to write SSTable: %v", err)
	}

	sstable := &SSTable{
		path: path,
	}

	value, found, err := sstable.Get("seat/ROOM101/A02")
	if err != nil {
		t.Fatalf("failed to read SSTable: %v", err)
	}

	if !found {
		t.Fatal("expected key to be found")
	}

	if value != "ALLOCATED:STU123" {
		t.Fatalf("expected ALLOCATED:STU123, got %s", value)
	}
}

func TestSSTableMissingKey(t *testing.T) {
	dir := t.TempDir()

	path := filepath.Join(dir, "sstable-001")

	data := map[string]string{
		"seat/ROOM101/A01": "FREE",
	}

	_, err := WriteSSTable(path, data)
	if err != nil {
		t.Fatalf("failed to write SSTable: %v", err)
	}

	sstable := &SSTable{
		path: path,
	}

	_, found, err := sstable.Get("seat/ROOM101/A99")
	if err != nil {
		t.Fatalf("failed to read SSTable: %v", err)
	}

	if found {
		t.Fatal("expected key not to be found")
	}
}
func TestSSTableReadAll(t *testing.T) {
	dir := t.TempDir()

	path := filepath.Join(dir, "sstable-001")

	data := map[string]string{
		"seat/ROOM101/A01": "FREE",
		"seat/ROOM101/A02": "ALLOCATED:STU123",
		"seat/ROOM101/A03": Tombstone,
	}

	if _, err := WriteSSTable(path, data); err != nil {
		t.Fatalf("failed to write SSTable: %v", err)
	}

	sstable := SSTable{
		path: path,
	}

	recovered, err := sstable.ReadAll()
	if err != nil {
		t.Fatalf("failed to read SSTable: %v", err)
	}

	if len(recovered) != 3 {
		t.Fatalf(
			"expected 3 entries, got %d",
			len(recovered),
		)
	}

	if recovered["seat/ROOM101/A01"] != "FREE" {
		t.Fatalf("unexpected A01 value: %s", recovered["seat/ROOM101/A01"])
	}

	if recovered["seat/ROOM101/A02"] != "ALLOCATED:STU123" {
		t.Fatalf(
			"unexpected A02 value: %s",
			recovered["seat/ROOM101/A02"],
		)
	}

	if recovered["seat/ROOM101/A03"] != Tombstone {
		t.Fatalf(
			"unexpected A03 value: %s",
			recovered["seat/ROOM101/A03"],
		)
	}
}
