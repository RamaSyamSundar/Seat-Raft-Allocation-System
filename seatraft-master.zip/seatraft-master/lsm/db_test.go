package lsm

import (
	"os"
	"path/filepath"
	"testing"
)

func TestDBPutAndFlush(t *testing.T) {
	dir := t.TempDir()

	db, err := OpenDB(dir)
	if err != nil {
		t.Fatalf("failed to open DB: %v", err)
	}

	defer db.Close()

	key := "seat/ROOM101/A01"
	value := "FREE"

	err = db.Put(key, value)
	if err != nil {
		t.Fatalf("failed to put value: %v", err)
	}

	got, exists := db.Get(key)

	if !exists {
		t.Fatal("expected key to exist in MemTable")
	}

	if got != value {
		t.Fatalf("expected %s, got %s", value, got)
	}

	err = db.Flush()
	if err != nil {
		t.Fatalf("failed to flush MemTable: %v", err)
	}

	sstablePath := filepath.Join(dir, "sstable-001")

	sstable := &SSTable{
		path: sstablePath,
	}

	got, found, err := sstable.Get(key)
	if err != nil {
		t.Fatalf("failed to read SSTable: %v", err)
	}

	if !found {
		t.Fatal("expected key to exist in SSTable")
	}

	if got != value {
		t.Fatalf("expected %s from SSTable, got %s", value, got)
	}
}

func TestDBGetFromSSTable(t *testing.T) {
	dir := t.TempDir()

	db, err := OpenDB(dir)
	if err != nil {
		t.Fatalf("failed to open DB: %v", err)
	}

	defer db.Close()

	key := "seat/ROOM101/A02"
	value := "ALLOCATED:STU123"

	if err := db.Put(key, value); err != nil {
		t.Fatalf("failed to put value: %v", err)
	}

	if err := db.Flush(); err != nil {
		t.Fatalf("failed to flush: %v", err)
	}

	db.memtable = NewMemTable()

	got, exists := db.Get(key)

	if !exists {
		t.Fatal("expected key to be found in SSTable")
	}

	if got != value {
		t.Fatalf("expected %s, got %s", value, got)
	}
}

func TestDBFlushRotatesMemTable(t *testing.T) {
	dir := t.TempDir()

	db, err := OpenDB(dir)
	if err != nil {
		t.Fatalf("failed to open DB: %v", err)
	}

	defer db.Close()

	key := "seat/ROOM101/A01"

	if err := db.Put(key, "FREE"); err != nil {
		t.Fatalf("failed to put first value: %v", err)
	}

	if err := db.Flush(); err != nil {
		t.Fatalf("failed to flush: %v", err)
	}

	if db.memtable.Len() != 0 {
		t.Fatalf(
			"expected new MemTable to be empty, got %d entries",
			db.memtable.Len(),
		)
	}

	newKey := "seat/ROOM101/A02"

	if err := db.Put(newKey, "FREE"); err != nil {
		t.Fatalf("failed to put second value: %v", err)
	}

	if db.memtable.Len() != 1 {
		t.Fatalf(
			"expected new MemTable to contain 1 entry, got %d",
			db.memtable.Len(),
		)
	}

	value, exists := db.Get(key)

	if !exists {
		t.Fatal("expected first key to be found")
	}

	if value != "FREE" {
		t.Fatalf("expected FREE, got %s", value)
	}

	value, exists = db.Get(newKey)

	if !exists {
		t.Fatal("expected second key to be found")
	}

	if value != "FREE" {
		t.Fatalf("expected FREE, got %s", value)
	}
}

func TestDBDeleteWithTombstone(t *testing.T) {
	dir := t.TempDir()

	db, err := OpenDB(dir)
	if err != nil {
		t.Fatalf("failed to open DB: %v", err)
	}

	defer db.Close()

	key := "seat/ROOM101/A03"
	value := "ALLOCATED:STU999"

	if err := db.Put(key, value); err != nil {
		t.Fatalf("failed to put value: %v", err)
	}

	if err := db.Flush(); err != nil {
		t.Fatalf("failed to flush: %v", err)
	}

	db.memtable.Delete(key)

	got, exists := db.Get(key)

	if exists {
		t.Fatalf("expected key to be deleted, got %s", got)
	}
}

func TestDBRecoversFromWAL(t *testing.T) {
	dir := t.TempDir()

	db, err := OpenDB(dir)
	if err != nil {
		t.Fatalf("failed to open DB: %v", err)
	}

	key := "seat/ROOM101/A04"
	value := "ALLOCATED:STU456"

	if err := db.Put(key, value); err != nil {
		t.Fatalf("failed to put value: %v", err)
	}

	if err := db.Close(); err != nil {
		t.Fatalf("failed to close DB: %v", err)
	}

	db, err = OpenDB(dir)
	if err != nil {
		t.Fatalf("failed to reopen DB: %v", err)
	}

	defer db.Close()

	got, exists := db.Get(key)

	if !exists {
		t.Fatal("expected value to be recovered from WAL")
	}

	if got != value {
		t.Fatalf("expected %s, got %s", value, got)
	}
}

func TestDBDelete(t *testing.T) {
	dir := t.TempDir()

	db, err := OpenDB(dir)
	if err != nil {
		t.Fatalf("failed to open DB: %v", err)
	}

	defer db.Close()

	key := "seat/ROOM101/A05"
	value := "ALLOCATED:STU789"

	if err := db.Put(key, value); err != nil {
		t.Fatalf("failed to put value: %v", err)
	}

	if err := db.Delete(key); err != nil {
		t.Fatalf("failed to delete value: %v", err)
	}

	_, exists := db.Get(key)

	if exists {
		t.Fatal("expected key to be deleted")
	}
}

func TestDBRecoversDeleteFromWAL(t *testing.T) {
	dir := t.TempDir()

	db, err := OpenDB(dir)
	if err != nil {
		t.Fatalf("failed to open DB: %v", err)
	}

	key := "seat/ROOM101/A06"
	value := "ALLOCATED:STU999"

	if err := db.Put(key, value); err != nil {
		t.Fatalf("failed to put value: %v", err)
	}

	if err := db.Delete(key); err != nil {
		t.Fatalf("failed to delete value: %v", err)
	}

	if err := db.Close(); err != nil {
		t.Fatalf("failed to close DB: %v", err)
	}

	db, err = OpenDB(dir)
	if err != nil {
		t.Fatalf("failed to reopen DB: %v", err)
	}

	defer db.Close()

	_, exists := db.Get(key)

	if exists {
		t.Fatal("expected deleted key to remain deleted after restart")
	}
}

func TestDBRecoversFromSSTable(t *testing.T) {
	dir := t.TempDir()

	db, err := OpenDB(dir)
	if err != nil {
		t.Fatalf("failed to open DB: %v", err)
	}

	key := "seat/ROOM101/A07"
	value := "ALLOCATED:STU111"

	if err := db.Put(key, value); err != nil {
		t.Fatalf("failed to put value: %v", err)
	}

	if err := db.Flush(); err != nil {
		t.Fatalf("failed to flush: %v", err)
	}

	if err := db.Close(); err != nil {
		t.Fatalf("failed to close DB: %v", err)
	}

	walPath := filepath.Join(dir, "wal.log")

	if err := os.Remove(walPath); err != nil {
		t.Fatalf("failed to remove WAL: %v", err)
	}

	db, err = OpenDB(dir)
	if err != nil {
		t.Fatalf("failed to reopen DB: %v", err)
	}

	defer db.Close()

	got, exists := db.Get(key)

	if !exists {
		t.Fatal("expected value to be recovered from SSTable")
	}

	if got != value {
		t.Fatalf("expected %s, got %s", value, got)
	}
}

func TestDBUsesNewestSSTableValue(t *testing.T) {
	dir := t.TempDir()

	db, err := OpenDB(dir)
	if err != nil {
		t.Fatalf("failed to open DB: %v", err)
	}

	defer db.Close()

	key := "seat/ROOM101/A08"

	if err := db.Put(key, "FREE"); err != nil {
		t.Fatalf("failed to put first value: %v", err)
	}

	if err := db.Flush(); err != nil {
		t.Fatalf("failed to flush first value: %v", err)
	}

	if err := db.Put(key, "ALLOCATED:STU222"); err != nil {
		t.Fatalf("failed to put second value: %v", err)
	}

	if err := db.Flush(); err != nil {
		t.Fatalf("failed to flush second value: %v", err)
	}

	got, exists := db.Get(key)

	if !exists {
		t.Fatal("expected key to exist")
	}

	if got != "ALLOCATED:STU222" {
		t.Fatalf("expected newest value, got %s", got)
	}
}

func TestDBUsesNewestSSTableAfterRestart(t *testing.T) {
	dir := t.TempDir()

	db, err := OpenDB(dir)
	if err != nil {
		t.Fatalf("failed to open DB: %v", err)
	}

	key := "seat/ROOM101/A09"

	if err := db.Put(key, "FREE"); err != nil {
		t.Fatalf("failed to put first value: %v", err)
	}

	if err := db.Flush(); err != nil {
		t.Fatalf("failed to flush first value: %v", err)
	}

	if err := db.Put(key, "ALLOCATED:STU333"); err != nil {
		t.Fatalf("failed to put second value: %v", err)
	}

	if err := db.Flush(); err != nil {
		t.Fatalf("failed to flush second value: %v", err)
	}

	if err := db.Close(); err != nil {
		t.Fatalf("failed to close DB: %v", err)
	}

	walPath := filepath.Join(dir, "wal.log")

	if err := os.Remove(walPath); err != nil {
		t.Fatalf("failed to remove WAL: %v", err)
	}

	db, err = OpenDB(dir)
	if err != nil {
		t.Fatalf("failed to reopen DB: %v", err)
	}

	defer db.Close()

	got, exists := db.Get(key)

	if !exists {
		t.Fatal("expected key to exist after restart")
	}

	if got != "ALLOCATED:STU333" {
		t.Fatalf("expected newest value, got %s", got)
	}
}

func TestDBTombstoneSurvivesFlushAndRestart(t *testing.T) {
	dir := t.TempDir()

	db, err := OpenDB(dir)
	if err != nil {
		t.Fatalf("failed to open DB: %v", err)
	}

	key := "seat/ROOM101/A10"
	value := "ALLOCATED:STU444"

	if err := db.Put(key, value); err != nil {
		t.Fatalf("failed to put value: %v", err)
	}

	if err := db.Flush(); err != nil {
		t.Fatalf("failed to flush value: %v", err)
	}

	if err := db.Delete(key); err != nil {
		t.Fatalf("failed to delete value: %v", err)
	}

	if err := db.Flush(); err != nil {
		t.Fatalf("failed to flush tombstone: %v", err)
	}

	if err := db.Close(); err != nil {
		t.Fatalf("failed to close DB: %v", err)
	}

	walPath := filepath.Join(dir, "wal.log")

	if err := os.Remove(walPath); err != nil {
		t.Fatalf("failed to remove WAL: %v", err)
	}

	db, err = OpenDB(dir)
	if err != nil {
		t.Fatalf("failed to reopen DB: %v", err)
	}

	defer db.Close()

	_, exists := db.Get(key)

	if exists {
		t.Fatal("expected deleted key to remain deleted after restart")
	}
}

func TestDBAutomaticFlush(t *testing.T) {
	dir := t.TempDir()

	db, err := OpenDB(dir)
	if err != nil {
		t.Fatalf("failed to open DB: %v", err)
	}

	defer db.Close()

	if err := db.Put("seat/ROOM101/A01", "FREE"); err != nil {
		t.Fatalf("failed to put A01: %v", err)
	}

	if err := db.Put("seat/ROOM101/A02", "FREE"); err != nil {
		t.Fatalf("failed to put A02: %v", err)
	}

	if err := db.Put("seat/ROOM101/A03", "FREE"); err != nil {
		t.Fatalf("failed to put A03: %v", err)
	}

	if len(db.sstables) != 1 {
		t.Fatalf(
			"expected 1 SSTable after automatic flush, got %d",
			len(db.sstables),
		)
	}

	if db.memtable.Len() != 0 {
		t.Fatalf(
			"expected empty MemTable after automatic flush, got %d entries",
			db.memtable.Len(),
		)
	}

	value, exists := db.Get("seat/ROOM101/A03")

	if !exists {
		t.Fatal("expected A03 to exist after automatic flush")
	}

	if value != "FREE" {
		t.Fatalf(
			"expected A03 to be FREE, got %s",
			value,
		)
	}
}

func TestDBCompactionKeepsNewestValues(t *testing.T) {
	dir := t.TempDir()

	db, err := OpenDB(dir)
	if err != nil {
		t.Fatalf("failed to open DB: %v", err)
	}

	defer db.Close()

	// First SSTable.
	if err := db.Put("seat/ROOM101/A01", "FREE"); err != nil {
		t.Fatalf("failed to put A01: %v", err)
	}

	if err := db.Put("seat/ROOM101/A02", "FREE"); err != nil {
		t.Fatalf("failed to put A02: %v", err)
	}

	if err := db.Put("seat/ROOM101/A03", "FREE"); err != nil {
		t.Fatalf("failed to put A03: %v", err)
	}

	// Second SSTable with a newer value for A01.
	if err := db.Put("seat/ROOM101/A01", "ALLOCATED:STU123"); err != nil {
		t.Fatalf("failed to update A01: %v", err)
	}

	if err := db.Put("seat/ROOM101/A04", "FREE"); err != nil {
		t.Fatalf("failed to put A04: %v", err)
	}

	if err := db.Put("seat/ROOM101/A05", "FREE"); err != nil {
		t.Fatalf("failed to put A05: %v", err)
	}

	if len(db.sstables) != 2 {
		t.Fatalf(
			"expected 2 SSTables before compaction, got %d",
			len(db.sstables),
		)
	}

	// The newest value must currently win.
	value, exists := db.Get("seat/ROOM101/A01")

	if !exists {
		t.Fatal("expected A01 to exist")
	}

	if value != "ALLOCATED:STU123" {
		t.Fatalf(
			"expected newest value ALLOCATED:STU123, got %s",
			value,
		)
	}

	// Compact the SSTables.
	if err := db.Compact(); err != nil {
		t.Fatalf("compaction failed: %v", err)
	}

	if len(db.sstables) != 1 {
		t.Fatalf(
			"expected 1 SSTable after compaction, got %d",
			len(db.sstables),
		)
	}

	// The newest value must survive compaction.
	value, exists = db.Get("seat/ROOM101/A01")

	if !exists {
		t.Fatal("expected A01 to exist after compaction")
	}

	if value != "ALLOCATED:STU123" {
		t.Fatalf(
			"expected newest value after compaction to be ALLOCATED:STU123, got %s",
			value,
		)
	}

	// Other keys from both SSTables must also survive.
	value, exists = db.Get("seat/ROOM101/A02")

	if !exists {
		t.Fatal("expected A02 to exist after compaction")
	}

	if value != "FREE" {
		t.Fatalf(
			"expected A02 to remain FREE after compaction, got %s",
			value,
		)
	}

	value, exists = db.Get("seat/ROOM101/A04")

	if !exists {
		t.Fatal("expected A04 to exist after compaction")
	}

	if value != "FREE" {
		t.Fatalf(
			"expected A04 to remain FREE after compaction, got %s",
			value,
		)
	}
}
func TestDBCompactionPreservesTombstone(t *testing.T) {
	dir := t.TempDir()

	db, err := OpenDB(dir)
	if err != nil {
		t.Fatalf("failed to open DB: %v", err)
	}

	defer db.Close()

	key := "seat/ROOM101/A11"

	// First SSTable contains the original value.
	if err := db.Put(key, "ALLOCATED:STU555"); err != nil {
		t.Fatalf("failed to put value: %v", err)
	}

	if err := db.Flush(); err != nil {
		t.Fatalf("failed to flush first SSTable: %v", err)
	}

	// Second SSTable contains the tombstone.
	if err := db.Delete(key); err != nil {
		t.Fatalf("failed to delete key: %v", err)
	}

	if err := db.Flush(); err != nil {
		t.Fatalf("failed to flush tombstone: %v", err)
	}

	if len(db.sstables) != 2 {
		t.Fatalf(
			"expected 2 SSTables before compaction, got %d",
			len(db.sstables),
		)
	}

	// The key must already appear deleted.
	_, exists := db.Get(key)

	if exists {
		t.Fatal("expected key to be deleted before compaction")
	}

	// Compact both SSTables.
	if err := db.Compact(); err != nil {
		t.Fatalf("compaction failed: %v", err)
	}

	if len(db.sstables) != 1 {
		t.Fatalf(
			"expected 1 SSTable after compaction, got %d",
			len(db.sstables),
		)
	}

	// The tombstone must survive compaction.
	_, exists = db.Get(key)

	if exists {
		t.Fatal("expected tombstone to remain after compaction")
	}

	// Verify the compacted SSTable actually contains the tombstone.
	data, err := db.sstables[0].ReadAll()
	if err != nil {
		t.Fatalf("failed to read compacted SSTable: %v", err)
	}

	if data[key] != Tombstone {
		t.Fatalf(
			"expected tombstone in compacted SSTable, got %q",
			data[key],
		)
	}
}