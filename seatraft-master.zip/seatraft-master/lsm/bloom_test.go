package lsm

import "testing"

func TestBloomFilter(t *testing.T) {
	filter := NewBloomFilter(1000)

	filter.Add("seat/ROOM101/A01")
	filter.Add("seat/ROOM101/A02")

	if !filter.MightContain("seat/ROOM101/A01") {
		t.Fatal("expected A01 to possibly exist")
	}

	if !filter.MightContain("seat/ROOM101/A02") {
		t.Fatal("expected A02 to possibly exist")
	}
}

func TestBloomFilterMissingKey(t *testing.T) {
	filter := NewBloomFilter(1000)

	filter.Add("seat/ROOM101/A01")

	if filter.MightContain("seat/ROOM101/A999") {
		t.Fatal("expected missing key to be reported as definitely absent")
	}
}
