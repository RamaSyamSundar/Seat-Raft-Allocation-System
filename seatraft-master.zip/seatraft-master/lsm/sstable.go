package lsm

import (
	"bufio"
	"os"
	"sort"
	"strings"
)

type SSTable struct {
	path  string
	bloom *BloomFilter
}

func WriteSSTable(path string, data map[string]string) (*BloomFilter, error) {
	file, err := os.Create(path)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	keys := make([]string, 0, len(data))

	for key := range data {
		keys = append(keys, key)
	}

	sort.Strings(keys)

	bloom := NewBloomFilter(1000)

	writer := bufio.NewWriter(file)

	for _, key := range keys {
		bloom.Add(key)

		line := key + "\t" + data[key] + "\n"

		if _, err := writer.WriteString(line); err != nil {
			return nil, err
		}
	}

	if err := writer.Flush(); err != nil {
		return nil, err
	}

	return bloom, nil
}

func (s *SSTable) ReadAll() (map[string]string, error) {
	file, err := os.Open(s.path)
	if err != nil {
		return nil, err
	}
	defer file.Close()

	data := make(map[string]string)

	scanner := bufio.NewScanner(file)

	for scanner.Scan() {
		parts := strings.SplitN(scanner.Text(), "\t", 2)

		if len(parts) != 2 {
			continue
		}

		data[parts[0]] = parts[1]
	}

	if err := scanner.Err(); err != nil {
		return nil, err
	}

	return data, nil
}

func (s *SSTable) Get(key string) (string, bool, error) {
	if s.bloom != nil && !s.bloom.MightContain(key) {
		return "", false, nil
	}

	file, err := os.Open(s.path)
	if err != nil {
		return "", false, err
	}
	defer file.Close()

	scanner := bufio.NewScanner(file)

	for scanner.Scan() {
		parts := strings.SplitN(scanner.Text(), "\t", 2)

		if len(parts) != 2 {
			continue
		}

		if parts[0] == key {
			return parts[1], true, nil
		}
	}

	if err := scanner.Err(); err != nil {
		return "", false, err
	}

	return "", false, nil
}
