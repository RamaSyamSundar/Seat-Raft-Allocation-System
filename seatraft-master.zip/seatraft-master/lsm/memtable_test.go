package lsm

import "testing"

func TestMemTablePutAndGet(t *testing.T) {
	memtable := NewMemTable()

	memtable.Put("seat/ROOM101/A01", "FREE")

	value, exists := memtable.Get("seat/ROOM101/A01")

	if !exists {
		t.Fatal("expected key to exist")
	}

	if value != "FREE" {
		t.Fatalf("expected FREE, got %s", value)
	}
}

func TestMemTableUpdate(t *testing.T) {
	memtable := NewMemTable()

	memtable.Put("seat/ROOM101/A01", "FREE")
	memtable.Put("seat/ROOM101/A01", "ALLOCATED:STU001")

	value, exists := memtable.Get("seat/ROOM101/A01")

	if !exists {
		t.Fatal("expected key to exist")
	}

	if value != "ALLOCATED:STU001" {
		t.Fatalf("unexpected value: %s", value)
	}
}

func TestMemTableDelete(t *testing.T) {
	memtable := NewMemTable()

	memtable.Put("seat/A01", "FREE")
	memtable.Delete("seat/A01")

	value, exists := memtable.Get("seat/A01")

	if !exists {
		t.Fatal("expected tombstone to exist")
	}

	if value != Tombstone {
		t.Fatalf("expected tombstone, got %s", value)
	}
}

func TestMemTableLen(t *testing.T) {
	memtable := NewMemTable()

	memtable.Put("seat/ROOM101/A01", "FREE")
	memtable.Put("seat/ROOM101/A02", "FREE")

	if memtable.Len() != 2 {
		t.Fatalf("expected length 2, got %d", memtable.Len())
	}
}
