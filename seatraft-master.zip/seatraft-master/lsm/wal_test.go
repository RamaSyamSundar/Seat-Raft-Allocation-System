package lsm

import (
	"path/filepath"
	"testing"
)

func TestWALAppendAndRead(t *testing.T) {
	dir := t.TempDir()

	walPath := filepath.Join(dir, "wal.log")

	wal, err := OpenWAL(walPath)
	if err != nil {
		t.Fatalf("failed to open WAL: %v", err)
	}

	defer wal.Close()

	err = wal.Append("PUT|seat/ROOM101/A01|FREE")
	if err != nil {
		t.Fatalf("failed to append first record: %v", err)
	}

	err = wal.Append("PUT|seat/ROOM101/A02|FREE")
	if err != nil {
		t.Fatalf("failed to append second record: %v", err)
	}

	records, err := ReadWAL(walPath)
	if err != nil {
		t.Fatalf("failed to read WAL: %v", err)
	}

	if len(records) != 2 {
		t.Fatalf("expected 2 records, got %d", len(records))
	}

	if records[0] != "PUT|seat/ROOM101/A01|FREE" {
		t.Fatalf("unexpected first record: %s", records[0])
	}

	if records[1] != "PUT|seat/ROOM101/A02|FREE" {
		t.Fatalf("unexpected second record: %s", records[1])
	}
}
func TestWALRecovery(t *testing.T) {
	dir := t.TempDir()

	walPath := filepath.Join(dir, "wal.log")

	// First server instance.
	wal, err := OpenWAL(walPath)
	if err != nil {
		t.Fatalf("failed to open WAL: %v", err)
	}

	if err := wal.Append("PUT|seat/ROOM101/A01|FREE"); err != nil {
		t.Fatalf("failed to append record: %v", err)
	}

	if err := wal.Append("PUT|seat/ROOM101/A02|FREE"); err != nil {
		t.Fatalf("failed to append record: %v", err)
	}

	// Simulate server shutdown/crash.
	if err := wal.Close(); err != nil {
		t.Fatalf("failed to close WAL: %v", err)
	}

	// Second server instance.
	recoveredRecords, err := ReadWAL(walPath)
	if err != nil {
		t.Fatalf("failed to recover WAL: %v", err)
	}

	if len(recoveredRecords) != 2 {
		t.Fatalf(
			"expected 2 recovered records, got %d",
			len(recoveredRecords),
		)
	}

	if recoveredRecords[0] != "PUT|seat/ROOM101/A01|FREE" {
		t.Fatalf(
			"unexpected first recovered record: %s",
			recoveredRecords[0],
		)
	}

	if recoveredRecords[1] != "PUT|seat/ROOM101/A02|FREE" {
		t.Fatalf(
			"unexpected second recovered record: %s",
			recoveredRecords[1],
		)
	}
}