package lsm

import "hash/fnv"

type BloomFilter struct {
	bits []bool
	size int
}

func NewBloomFilter(size int) *BloomFilter {
	return &BloomFilter{
		bits: make([]bool, size),
		size: size,
	}
}

func (b *BloomFilter) Add(key string) {
	index := b.hash(key)

	b.bits[index] = true
}

func (b *BloomFilter) MightContain(key string) bool {
	index := b.hash(key)

	return b.bits[index]
}

func (b *BloomFilter) hash(key string) int {
	hasher := fnv.New32a()

	_, _ = hasher.Write([]byte(key))

	return int(hasher.Sum32() % uint32(b.size))
}
