package main

import (
	"context"
	"fmt"
	"log"
	"net"
	"os"
	"strings"
	"time"

	"google.golang.org/grpc"

	"seatraft/lsm"
	pb "seatraft/proto"
	"seatraft/raft"
)

type seatAllocationServer struct {
	pb.UnimplementedSeatAllocationServer
	service *raft.Service
}

func (s *seatAllocationServer) Get(
	ctx context.Context,
	req *pb.GetRequest,
) (*pb.GetResponse, error) {
	value, exists := s.service.Get(req.GetKey())

	return &pb.GetResponse{
		Value:  value,
		Exists: exists,
	}, nil
}

func (s *seatAllocationServer) Put(
	ctx context.Context,
	req *pb.PutRequest,
) (*pb.PutResponse, error) {
	success := s.service.Put(
		req.GetKey(),
		req.GetValue(),
	)

	return &pb.PutResponse{
		Success: success,
	}, nil
}

func (s *seatAllocationServer) Delete(
	ctx context.Context,
	req *pb.DeleteRequest,
) (*pb.DeleteResponse, error) {
	success := s.service.Delete(
		req.GetKey(),
	)

	return &pb.DeleteResponse{
		Success: success,
	}, nil
}

func (s *seatAllocationServer) Allocate(
	ctx context.Context,
	req *pb.AllocateRequest,
) (*pb.AllocateResponse, error) {
	success := s.service.Allocate(
		req.GetKey(),
		req.GetStudentId(),
	)

	return &pb.AllocateResponse{
		Success: success,
	}, nil
}

func connectToPeerWithRetry(
	cluster *raft.Cluster,
	nodeID string,
) {
	for {
		if err := cluster.ConnectRemotePeer(nodeID); err == nil {
			log.Printf("Connected to Raft peer %s", nodeID)
			return
		}

		log.Printf(
			"Waiting for Raft peer %s...",
			nodeID,
		)

		time.Sleep(2 * time.Second)
	}
}

func resolveNodeID() string {
	nodeID := os.Getenv("NODE_ID")

	// Kubernetes StatefulSet gives us:
	//
	// seatraft-0
	// seatraft-1
	// seatraft-2
	//
	// Convert them to:
	//
	// node1
	// node2
	// node3

	switch nodeID {
	case "seatraft-0":
		return "node1"
	case "seatraft-1":
		return "node2"
	case "seatraft-2":
		return "node3"
	}

	// Also allow directly supplying node1/node2/node3.
	if nodeID == "node1" ||
		nodeID == "node2" ||
		nodeID == "node3" {
		return nodeID
	}

	if nodeID == "" {
		return "node1"
	}

	return nodeID
}

func main() {
	nodeID := resolveNodeID()

	allNodeIDs := []string{
		"node1",
		"node2",
		"node3",
	}

	// Every process knows the complete Raft membership.
	cluster := raft.NewCluster(allNodeIDs)

	node, exists := cluster.Nodes[nodeID]
	if !exists {
		log.Fatalf("Raft node %s was not created", nodeID)
	}

	peerAddresses := map[string]string{
		"node1": os.Getenv("NODE1_ADDR"),
		"node2": os.Getenv("NODE2_ADDR"),
		"node3": os.Getenv("NODE3_ADDR"),
	}

	for peerID, address := range peerAddresses {
		if address == "" {
			continue
		}

		if !cluster.SetAddress(peerID, address) {
			log.Fatalf(
				"failed to configure address for %s: %s",
				peerID,
				address,
			)
		}
	}

	dir := "data/" + nodeID

	if err := os.MkdirAll(dir, 0755); err != nil {
		log.Fatalf(
			"failed to create database directory for %s: %v",
			nodeID,
			err,
		)
	}

	db, err := lsm.OpenDB(dir)
	if err != nil {
		log.Fatalf(
			"failed to open database for %s: %v",
			nodeID,
			err,
		)
	}

	defer func() {
		if err := db.Close(); err != nil {
			log.Printf(
				"failed to close database for %s: %v",
				nodeID,
				err,
			)
		}
	}()

	node.SetStateMachine(
		raft.NewStateMachine(db),
	)

	raftStatePath := dir + "/raft-state.json"

	if err := node.SetPersistencePath(raftStatePath); err != nil {
		log.Fatalf(
			"failed to set Raft persistence path for %s: %v",
			nodeID,
			err,
		)
	}

	if err := node.LoadPersistentState(); err != nil {
		log.Fatalf(
			"failed to load Raft state for %s: %v",
			nodeID,
			err,
		)
	}

	// Start the gRPC server before attempting to connect to peers.
	listener, err := net.Listen("tcp", ":50051")
	if err != nil {
		log.Fatalf("failed to listen: %v", err)
	}

	grpcServer := grpc.NewServer()

	server := &seatAllocationServer{}

	raftServer := raft.NewGRPCService(node)

	pb.RegisterSeatAllocationServer(
		grpcServer,
		server,
	)

	pb.RegisterRaftServer(
		grpcServer,
		raftServer,
	)

	log.Printf(
		"SeatRaft gRPC server listening on :50051",
	)

	log.Printf(
		"Raft node: %s",
		nodeID,
	)

	for peerID, address := range peerAddresses {
		if address == "" {
			continue
		}

		log.Printf(
			"Raft peer %s: %s",
			peerID,
			address,
		)
	}

	go func() {
		if err := grpcServer.Serve(listener); err != nil {
			log.Fatalf(
				"failed to serve: %v",
				err,
			)
		}
	}()

	// Give the local gRPC server a moment to start.
	time.Sleep(500 * time.Millisecond)

	// Connect to every remote Raft node.
	for peerID, address := range peerAddresses {
		if peerID == nodeID || address == "" {
			continue
		}

		go connectToPeerWithRetry(
			cluster,
			peerID,
		)
	}

	// Wait until the configured remote peers are connected.
	for {
		allConnected := true

		clusterAddresses := []string{
			"node1",
			"node2",
			"node3",
		}

		for _, peerID := range clusterAddresses {
			if peerID == nodeID {
				continue
			}

			if peerAddresses[peerID] == "" {
				continue
			}

			if !cluster.HasPeerConnection(peerID) {
				allConnected = false
				break
			}
		}

		if allConnected {
			break
		}

		time.Sleep(500 * time.Millisecond)
	}

	log.Printf(
		"All configured Raft peers connected for %s",
		nodeID,
	)

	// Create the application service after cluster configuration.
	service := raft.NewService(
		cluster,
		nodeID,
	)

	server.service = service

	// Bootstrap leadership only from node1.
	//
	// node2 and node3 wait for Raft RPCs instead of independently
	// declaring themselves leader.
	if nodeID == "node1" {
		if !cluster.ElectLeader(nodeID) {
			log.Printf(
				"Node %s could not establish leadership",
				nodeID,
			)
		} else {
			log.Printf(
				"Raft leader: %s",
				nodeID,
			)
		}
	} else {
		log.Printf(
			"Raft node %s waiting for leader election",
			nodeID,
		)
	}

	// Keep the server alive.
	select {}
}

func init() {
	// Ensure the imported strings package remains available for
	// future Kubernetes node-name parsing.
	_ = strings.TrimSpace

	// Ensure fmt remains available for startup diagnostics.
	_ = fmt.Sprintf
}