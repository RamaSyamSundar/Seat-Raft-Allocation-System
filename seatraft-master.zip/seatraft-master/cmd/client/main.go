package main

import (
	"context"
	"fmt"
	"log"
	"os"
	"sync"
	"time"

	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials/insecure"

	pb "seatraft/proto"
)

func main() {
	address := os.Getenv("SEATRAFT_ADDR")
	if address == "" {
		address = "127.0.0.1:50051"
	}

	conn, err := grpc.NewClient(
		address,
		grpc.WithTransportCredentials(insecure.NewCredentials()),
	)
	if err != nil {
		log.Fatalf("Failed to create gRPC client: %v", err)
	}
	defer conn.Close()

	client := pb.NewSeatAllocationClient(conn)

	ctx, cancel := context.WithTimeout(
		context.Background(),
		60*time.Second,
	)
	defer cancel()

	// Initialize one seat as available.
	_, err = client.Put(ctx, &pb.PutRequest{
		Key:   "seat/ROOM101/A01",
		Value: "FREE",
	})
	if err != nil {
		log.Fatalf("Put failed: %v", err)
	}

	const numberOfStudents = 100

	var wg sync.WaitGroup
	var mu sync.Mutex

	successCount := 0
	failureCount := 0
	rpcErrorCount := 0

	fmt.Printf(
		"Starting concurrent allocation test with %d students\n",
		numberOfStudents,
	)

	for i := 1; i <= numberOfStudents; i++ {
		wg.Add(1)

		go func(studentNumber int) {
			defer wg.Done()

			studentID := fmt.Sprintf("STU%03d", studentNumber)

			requestCtx, requestCancel := context.WithTimeout(
				ctx,
				15*time.Second,
			)
			defer requestCancel()

			response, err := client.Allocate(
				requestCtx,
				&pb.AllocateRequest{
					Key:       "seat/ROOM101/A01",
					StudentId: studentID,
				},
			)

			mu.Lock()
			defer mu.Unlock()

			if err != nil {
				rpcErrorCount++
				fmt.Printf("%s -> RPC error: %v\n", studentID, err)
				return
			}

			if response.GetSuccess() {
				successCount++
				fmt.Printf("%s -> ALLOCATED\n", studentID)
			} else {
				failureCount++
			}
		}(i)
	}

	wg.Wait()

	getResponse, err := client.Get(
		ctx,
		&pb.GetRequest{
			Key: "seat/ROOM101/A01",
		},
	)
	if err != nil {
		log.Fatalf("Get failed: %v", err)
	}

	fmt.Println()
	fmt.Println("========== TEST RESULTS ==========")
	fmt.Printf("Total students:          %d\n", numberOfStudents)
	fmt.Printf("Successful allocations:   %d\n", successCount)
	fmt.Printf("Rejected allocations:     %d\n", failureCount)
	fmt.Printf("RPC errors:               %d\n", rpcErrorCount)
	fmt.Printf("Final seat value:         %s\n", getResponse.GetValue())

	if successCount == 1 {
		fmt.Println("RESULT: Exactly one allocation succeeded.")
	} else {
		fmt.Println("RESULT: Expected exactly one successful allocation.")
	}
	fmt.Println("==================================")
}
